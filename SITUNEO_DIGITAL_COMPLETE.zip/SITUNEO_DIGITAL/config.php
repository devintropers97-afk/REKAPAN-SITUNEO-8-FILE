<?php
/**
 * ========================================
 * SITUNEO DIGITAL - Configuration File
 * NIB: 20250-9261-4570-4515-5453
 * ========================================
 */

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'situneo_digital');

// Application Configuration
define('APP_NAME', 'SITUNEO DIGITAL');
define('APP_TAGLINE', 'Digital Harmony');
define('APP_URL', 'https://situneo.my.id');
define('APP_VERSION', '1.0.0');

// Company Information
define('COMPANY_NAME', 'SITUNEO DIGITAL');
define('COMPANY_NIB', '20250-9261-4570-4515-5453');
define('COMPANY_EMAIL', 'support@situneo.my.id');
define('COMPANY_PHONE', '+62 831-7386-8915');
define('COMPANY_ADDRESS', 'Jakarta Timur, Indonesia');

// Security Configuration
define('MIN_PASSWORD_LENGTH', 8);
define('SESSION_LIFETIME', 3600 * 24); // 24 hours
define('REMEMBER_ME_LIFETIME', 3600 * 24 * 30); // 30 days
define('RESET_TOKEN_EXPIRY', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_DURATION', 1800); // 30 minutes

// Upload Configuration
define('UPLOAD_PATH', __DIR__ . '/uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

// Email Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your_email@gmail.com');
define('SMTP_PASSWORD', 'your_password');
define('SMTP_FROM_EMAIL', 'noreply@situneo.my.id');
define('SMTP_FROM_NAME', 'SITUNEO DIGITAL');

// Role Definitions
define('ROLE_ADMIN', 'admin');
define('ROLE_USER', 'user');

// Database Connection
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    
} catch (Exception $e) {
    die("Database connection error: " . $e->getMessage());
}

// Include Functions
require_once __DIR__ . '/functions.php';

// Error Reporting (Development Mode)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('Asia/Jakarta');
