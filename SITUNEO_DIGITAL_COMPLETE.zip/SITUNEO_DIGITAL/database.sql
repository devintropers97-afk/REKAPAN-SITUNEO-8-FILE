-- ========================================
-- SITUNEO DIGITAL - Database Schema
-- NIB: 20250-9261-4570-4515-5453
-- Version: 1.0.0
-- ========================================

-- Create Database
CREATE DATABASE IF NOT EXISTS `situneo_digital` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `situneo_digital`;

-- ========================================
-- Table: users
-- ========================================
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `email_verify_token` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expiry` int(11) DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `login_attempts` int(11) NOT NULL DEFAULT 0,
  `lockout_until` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: services
-- ========================================
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `icon` varchar(100) DEFAULT 'gear',
  `image` varchar(255) DEFAULT NULL,
  `price_start` decimal(15,2) NOT NULL,
  `price_unit` varchar(50) DEFAULT 'paket',
  `features` text DEFAULT NULL COMMENT 'JSON array of features',
  `perfect_for` text DEFAULT NULL,
  `delivery_time` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `order_count` int(11) NOT NULL DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category` (`category`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: orders
-- ========================================
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `status` enum('pending','in_progress','completed','cancelled','refunded') NOT NULL DEFAULT 'pending',
  `payment_status` enum('unpaid','paid','partial','refunded') NOT NULL DEFAULT 'unpaid',
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_proof` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `user_id` (`user_id`),
  KEY `service_id` (`service_id`),
  KEY `status` (`status`),
  KEY `payment_status` (`payment_status`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: invoices
-- ========================================
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `tax` decimal(15,2) DEFAULT 0.00,
  `discount` decimal(15,2) DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `status` enum('draft','sent','paid','overdue','cancelled') NOT NULL DEFAULT 'draft',
  `due_date` date DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `order_id` (`order_id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: support_tickets
-- ========================================
CREATE TABLE `support_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ticket_number` varchar(50) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT 'general',
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `status` enum('open','in_progress','waiting_customer','resolved','closed') NOT NULL DEFAULT 'open',
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `resolved_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_number` (`ticket_number`),
  KEY `user_id` (`user_id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `status` (`status`),
  CONSTRAINT `support_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `support_tickets_ibfk_2` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: ticket_messages
-- ========================================
CREATE TABLE `ticket_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `attachments` text DEFAULT NULL COMMENT 'JSON array of attachments',
  `is_internal` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `ticket_messages_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ticket_messages_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: activity_logs
-- ========================================
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action` (`action`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: settings
-- ========================================
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(255) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: portfolio
-- ========================================
CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `completion_date` date DEFAULT NULL,
  `technologies` text DEFAULT NULL COMMENT 'JSON array',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `order_index` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category` (`category`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Insert Default Data
-- ========================================

-- Default Admin User
INSERT INTO `users` (`name`, `email`, `password`, `role`, `status`, `email_verified`, `created_at`) VALUES
('Administrator', 'admin@situneo.my.id', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 1, NOW());
-- Password: Admin123!

-- Default User
INSERT INTO `users` (`name`, `email`, `password`, `role`, `status`, `email_verified`, `created_at`) VALUES
('Test User', 'user@example.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user', 'active', 1, NOW());
-- Password: User123!

-- Default Settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES
('company_name', 'SITUNEO DIGITAL', 'Company name'),
('company_tagline', 'Digital Harmony', 'Company tagline'),
('company_nib', '20250-9261-4570-4515-5453', 'NIB number'),
('company_email', 'support@situneo.my.id', 'Company email'),
('support_email', 'support@situneo.my.id', 'Support email'),
('company_phone', '+62 831-7386-8915', 'Company phone'),
('company_address', 'Jakarta Timur, Indonesia', 'Company address'),
('company_website', 'https://situneo.my.id', 'Company website'),
('whatsapp_number', '6283173868915', 'WhatsApp number'),
('smtp_host', 'smtp.gmail.com', 'SMTP host'),
('smtp_port', '587', 'SMTP port'),
('smtp_username', '', 'SMTP username'),
('smtp_password', '', 'SMTP password'),
('min_password_length', '8', 'Minimum password length'),
('session_lifetime', '86400', 'Session lifetime in seconds'),
('remember_lifetime', '2592000', 'Remember me lifetime in seconds'),
('max_upload_size', '5242880', 'Max upload size in bytes (5MB)');

-- ========================================
-- Insert Sample Services (26 Layanan)
-- ========================================
INSERT INTO `services` (`name`, `slug`, `category`, `description`, `icon`, `image`, `price_start`, `price_unit`, `features`, `perfect_for`, `delivery_time`, `status`) VALUES
('Company Profile Website', 'company-profile-website', 'Website Development', 'Website profesional untuk profil perusahaan Anda dengan desain modern dan responsive', 'globe', 'https://via.placeholder.com/400x300/1E5C99/FFFFFF?text=Company+Profile', 1500000.00, 'paket', '["Desain Modern & Professional", "Responsive Mobile", "SEO Friendly", "Admin Panel", "Domain & Hosting 1 Tahun", "SSL Certificate", "Google Maps Integration", "Contact Form", "Live Chat WhatsApp", "Maintenance 3 Bulan"]', 'Perusahaan startup, UMKM, korporat', '7-14 hari kerja', 'active'),

('Landing Page', 'landing-page', 'Website Development', 'Landing page yang menarik untuk campaign, produk, atau event dengan conversion rate tinggi', 'layout-text-window', 'https://via.placeholder.com/400x300/1E5C99/FFFFFF?text=Landing+Page', 800000.00, 'halaman', '["Design Modern", "Mobile Responsive", "Fast Loading", "CTA Button Optimized", "Contact Form", "Social Media Integration", "Analytics Tracking", "Free Revisi 2x", "Support 1 Bulan"]', 'Campaign marketing, peluncuran produk, event', '3-5 hari kerja', 'active'),

('Toko Online / E-Commerce', 'toko-online-ecommerce', 'Website Development', 'Toko online lengkap dengan sistem pembayaran, katalog produk, dan manajemen order', 'cart', 'https://via.placeholder.com/400x300/1E5C99/FFFFFF?text=E-Commerce', 3500000.00, 'paket', '["Katalog Produk Unlimited", "Sistem Pembayaran Gateway", "Keranjang Belanja", "Dashboard Admin", "Manajemen Order", "Notifikasi Email & WhatsApp", "Multi Kategori Produk", "Promo & Diskon", "Tracking Pengiriman", "Mobile App Ready"]', 'Bisnis retail, fashion, makanan, UMKM', '14-21 hari kerja', 'active'),

('Sistem Booking/Reservasi', 'sistem-booking-reservasi', 'Website Development', 'Aplikasi booking online untuk hotel, restoran, klinik, atau salon dengan kalender dan notifikasi otomatis', 'calendar-check', 'https://via.placeholder.com/400x300/1E5C99/FFFFFF?text=Booking+System', 2500000.00, 'paket', '["Kalender Booking Real-time", "Notifikasi Otomatis", "Payment Gateway", "Manajemen Jadwal", "Dashboard Admin", "Reminder WhatsApp", "Review & Rating", "Multi User Support", "Export Report"]', 'Hotel, klinik, salon, restoran, venue', '10-14 hari kerja', 'active'),

('Web Portal Berita', 'web-portal-berita', 'Website Development', 'Portal berita lengkap dengan CMS, kategori, dan sistem komentar', 'newspaper', 'https://via.placeholder.com/400x300/1E5C99/FFFFFF?text=News+Portal', 2000000.00, 'paket', '["Content Management System", "Multi Kategori", "Artikel Terjadwal", "Komentar & Rating", "Gallery Foto/Video", "Breaking News Alert", "Social Share", "SEO Optimized", "Advertisement Space", "Mobile Responsive"]', 'Media online, blogger, komunitas', '10-14 hari kerja', 'active'),

('Web Aplikasi Custom', 'web-aplikasi-custom', 'Website Development', 'Aplikasi web custom sesuai kebutuhan bisnis Anda dengan fitur advanced', 'code-square', 'https://via.placeholder.com/400x300/1E5C99/FFFFFF?text=Custom+App', 5000000.00, 'project', '["Analisis Kebutuhan", "Custom Design", "Database Design", "API Development", "User Management", "Dashboard Analytics", "Export/Import Data", "Multi Language", "Documentation", "Training & Support"]', 'Enterprise, startup tech, sistem internal', '30-60 hari kerja', 'active'),

('SEO Optimization', 'seo-optimization', 'Digital Marketing', 'Optimasi SEO lengkap untuk meningkatkan ranking website di Google', 'search', 'https://via.placeholder.com/400x300/FFB400/0F3057?text=SEO', 2000000.00, 'bulan', '["Keyword Research", "On-Page SEO", "Technical SEO", "Content Optimization", "Backlink Building", "Google Search Console Setup", "Analytics Tracking", "Competitor Analysis", "Monthly Report", "SEO Consultation"]', 'Bisnis online, e-commerce, company profile', 'Ongoing monthly', 'active'),

('Google Ads Management', 'google-ads-management', 'Digital Marketing', 'Pengelolaan kampanye Google Ads profesional dengan ROI maksimal', 'badge-ad', 'https://via.placeholder.com/400x300/FFB400/0F3057?text=Google+Ads', 1500000.00, 'bulan', '["Campaign Setup", "Keyword Targeting", "Ad Copy Writing", "A/B Testing", "Conversion Tracking", "Budget Management", "Negative Keywords", "Performance Optimization", "Weekly Report", "Strategy Consultation"]', 'Bisnis yang butuh traffic cepat, product launch', 'Ongoing monthly', 'active'),

('Facebook & Instagram Ads', 'facebook-instagram-ads', 'Digital Marketing', 'Iklan Facebook dan Instagram yang efektif untuk reach maksimal', 'facebook', 'https://via.placeholder.com/400x300/FFB400/0F3057?text=FB+IG+Ads', 1200000.00, 'bulan', '["Audience Targeting', 'Creative Design", "Ad Copy Writing", "A/B Testing", "Pixel Setup", "Retargeting Campaign", "Lookalike Audience", "Performance Report", "Conversion Optimization", "Community Management"]', 'Brand awareness, e-commerce, online shop', 'Ongoing monthly', 'active'),

('Social Media Management', 'social-media-management', 'Digital Marketing', 'Pengelolaan social media profesional untuk meningkatkan engagement', 'instagram', 'https://via.placeholder.com/400x300/FFB400/0F3057?text=Social+Media', 1000000.00, 'bulan', '["Content Planning", "Graphic Design Post", "Caption Writing", "Scheduling Post", "Story Management", "Engagement Handle", "Growth Strategy", "Analytics Report", "Competitor Monitoring", "Trend Analysis"]', 'Brand, influencer, bisnis online', 'Ongoing monthly', 'active'),

('Content Marketing', 'content-marketing', 'Digital Marketing', 'Strategi content marketing lengkap untuk meningkatkan brand awareness', 'file-text', 'https://via.placeholder.com/400x300/FFB400/0F3057?text=Content+Marketing', 1500000.00, 'bulan', '["Content Strategy", "Blog Writing", "SEO Article", "Infographic Design", "Video Script", "Email Newsletter", "Content Calendar", "Distribution Strategy", "Performance Analysis", "Content Audit"]', 'B2B, B2C, education, tech startup', 'Ongoing monthly', 'active'),

('Email Marketing', 'email-marketing', 'Digital Marketing', 'Campaign email marketing yang efektif dengan automation', 'envelope', 'https://via.placeholder.com/400x300/FFB400/0F3057?text=Email+Marketing', 800000.00, 'bulan', '["Email Template Design", "List Segmentation", "Campaign Setup", "Automation Workflow", "A/B Testing", "Performance Tracking", "Deliverability Optimization", "Newsletter Creation", "Lead Nurturing", "Monthly Report"]', 'E-commerce, SaaS, membership site', 'Ongoing monthly', 'active'),

('Logo Design', 'logo-design', 'Design Services', 'Desain logo profesional dan memorable untuk brand Anda', 'palette', 'https://via.placeholder.com/400x300/0F3057/FFB400?text=Logo+Design', 500000.00, 'paket', '["3 Konsep Desain", "Revisi Unlimited", "File Vector (AI, EPS)', 'File PNG & JPG", "Brand Guideline", "Social Media Kit", "Favicon", "Logo Variations", "Commercial License", "Fast Response"]', 'Startup, rebranding, bisnis baru', '3-5 hari kerja', 'active'),

('Brand Identity', 'brand-identity', 'Design Services', 'Paket lengkap brand identity untuk bisnis Anda', 'award', 'https://via.placeholder.com/400x300/0F3057/FFB400?text=Brand+Identity', 2000000.00, 'paket', '["Logo Design", "Color Palette", "Typography Guide", "Brand Guideline", "Business Card", "Letterhead", "Email Signature", "Social Media Template", "Presentation Template", "Brand Assets"]', 'Perusahaan baru, rebranding, expansion', '7-14 hari kerja', 'active'),

('UI/UX Design', 'ui-ux-design', 'Design Services', 'Desain UI/UX profesional untuk aplikasi web dan mobile', 'brush', 'https://via.placeholder.com/400x300/0F3057/FFB400?text=UI+UX+Design', 3000000.00, 'project', '["User Research", "Wireframe", "Mockup Design", "Prototype Interactive", "User Flow", "Design System", "Responsive Design", "Usability Testing", "Design Handoff", "Revisi 3x"]', 'Aplikasi web, mobile app, dashboard', '14-21 hari kerja', 'active'),

('Graphic Design', 'graphic-design', 'Design Services', 'Desain grafis untuk berbagai kebutuhan marketing Anda', 'image', 'https://via.placeholder.com/400x300/0F3057/FFB400?text=Graphic+Design', 300000.00, 'desain', '["Poster Design", "Flyer Design", "Banner Design", "Social Media Post", "Infographic", "Brochure", "Catalog Design", "High Resolution", "Print Ready", "Fast Delivery"]', 'Marketing material, campaign, promosi', '1-3 hari kerja', 'active'),

('Video Editing', 'video-editing', 'Design Services', 'Editing video profesional untuk content marketing dan promosi', 'film', 'https://via.placeholder.com/400x300/0F3057/FFB400?text=Video+Editing', 500000.00, 'video', '["Professional Editing", "Color Grading", "Motion Graphics", "Text Animation", "Sound Design", "Subtitle", "HD/4K Export", "Multiple Format", "Stock Footage", "Fast Turnaround"]', 'YouTube, Instagram, TikTok, marketing', '3-5 hari kerja', 'active'),

('Animation', 'animation', 'Design Services', 'Animasi 2D/3D untuk explainer video dan marketing', 'play-circle', 'https://via.placeholder.com/400x300/0F3057/FFB400?text=Animation', 1500000.00, 'video', '["2D/3D Animation", "Character Design", "Storyboard", "Voice Over", "Background Music", "HD Export", "Explainer Video", "Product Animation", "Revisi 2x", "Commercial License"]', 'Explainer video, product demo, education', '7-14 hari kerja', 'active'),

('Chatbot AI Development', 'chatbot-ai-development', 'Tech Solutions', 'Chatbot AI untuk customer service otomatis 24/7', 'robot', 'https://via.placeholder.com/400x300/1E5C99/FFB400?text=Chatbot+AI', 3000000.00, 'paket', '["Natural Language Processing", "Custom Training", "Multi Platform", "Live Chat Integration", "Analytics Dashboard", "Auto Response", "Lead Capture", "Sentiment Analysis", "API Integration", "24/7 Support"]', 'E-commerce, customer service, lead generation', '14-21 hari kerja', 'active'),

('WhatsApp Business API', 'whatsapp-business-api', 'Tech Solutions', 'Integrasi WhatsApp Business API untuk komunikasi bisnis', 'whatsapp', 'https://via.placeholder.com/400x300/1E5C99/FFB400?text=WA+Business', 2000000.00, 'paket', '["API Setup", "Auto Reply", "Broadcast Message", "Contact Management", "Message Template", "Analytics Report", "Multi Agent", "Chatbot Integration", "CRM Integration", "Training"]', 'Customer service, marketing, e-commerce', '7-10 hari kerja', 'active'),

('CRM System', 'crm-system', 'Tech Solutions', 'Customer Relationship Management system untuk bisnis Anda', 'people', 'https://via.placeholder.com/400x300/1E5C99/FFB400?text=CRM+System', 5000000.00, 'paket', '["Lead Management", "Sales Pipeline", "Contact Database", "Task Automation", "Email Integration", "Report & Analytics", "Mobile Access", "Team Collaboration", "API Integration", "Custom Fields"]', 'Sales team, B2B, service company', '21-30 hari kerja', 'active'),

('ERP System', 'erp-system', 'Tech Solutions', 'Enterprise Resource Planning untuk efisiensi bisnis', 'clipboard-data', 'https://via.placeholder.com/400x300/1E5C99/FFB400?text=ERP+System', 10000000.00, 'paket', '["Inventory Management", "Finance & Accounting", "HR Management", "Sales & Purchase", "Production Planning", "Multi Branch", "Role Management", "Report Generator", "API Integration", "Training & Support"]', 'Manufacturing, retail, distribution', '60-90 hari kerja', 'active'),

('Mobile App Development', 'mobile-app-development', 'Tech Solutions', 'Pengembangan aplikasi mobile Android dan iOS', 'phone', 'https://via.placeholder.com/400x300/1E5C99/FFB400?text=Mobile+App', 15000000.00, 'project', '["Android & iOS", "Custom Design", "Backend Development", "Push Notification", "In-App Purchase", "API Integration", "Admin Panel", "App Store Publish", "Bug Fix 3 Bulan", "Documentation"]', 'Startup, e-commerce, on-demand service', '60-90 hari kerja', 'active'),

('API Integration', 'api-integration', 'Tech Solutions', 'Integrasi API untuk koneksi antar sistem', 'link-45deg', 'https://via.placeholder.com/400x300/1E5C99/FFB400?text=API+Integration', 2000000.00, 'integration', '["Payment Gateway", "Shipping API", "Social Media API", "Third Party Service", "Data Sync", "Webhook Setup", "Error Handling", "Documentation", "Testing", "Support 1 Bulan"]', 'E-commerce, fintech, SaaS', '7-14 hari kerja', 'active'),

('Cloud Migration', 'cloud-migration', 'Tech Solutions', 'Migrasi sistem ke cloud untuk efisiensi dan skalabilitas', 'cloud-arrow-up', 'https://via.placeholder.com/400x300/1E5C99/FFB400?text=Cloud+Migration', 5000000.00, 'project', '["Cloud Assessment", "Migration Planning", "Data Migration", "Application Migration", "Testing & Validation", "Performance Optimization", "Security Setup", "Backup Strategy", "Training", "Post-Migration Support"]', 'Enterprise, growing business, cost optimization', '30-45 hari kerja', 'active'),

('IT Consulting', 'it-consulting', 'Tech Solutions', 'Konsultasi IT untuk strategi teknologi bisnis Anda', 'lightbulb', 'https://via.placeholder.com/400x300/1E5C99/FFB400?text=IT+Consulting', 1000000.00, 'sesi', '["Technology Assessment", "Strategic Planning", "Solution Architecture", "Vendor Selection", "Cost Optimization", "Risk Management", "Security Audit", "Digital Transformation", "Best Practice", "Roadmap Development"]', 'C-level, IT manager, business owner', '2-4 jam per sesi', 'active');

-- ========================================
-- End of Database Schema
-- ========================================
