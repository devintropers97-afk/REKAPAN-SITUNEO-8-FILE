# 📖 PANDUAN INSTALASI SITUNEO DIGITAL

## 📋 Persyaratan Sistem

### Minimum Requirements
- **PHP:** 8.0 atau lebih tinggi
- **MySQL:** 8.0 atau lebih tinggi
- **Web Server:** Apache 2.4+ atau Nginx 1.18+
- **Disk Space:** Minimal 500MB
- **RAM:** Minimal 512MB

### PHP Extensions Required
- mysqli
- pdo_mysql
- mbstring
- openssl
- json
- curl
- gd atau imagick
- fileinfo
- zip

## 🚀 Langkah Instalasi

### 1. Download & Extract
```bash
# Clone dari GitHub
git clone https://github.com/username/situneo-digital.git

# Atau extract file ZIP
unzip situneo-digital.zip
cd situneo-digital
```

### 2. Buat Database
```sql
# Login ke MySQL
mysql -u root -p

# Buat database baru
CREATE DATABASE situneo_digital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Keluar dari MySQL
EXIT;
```

### 3. Import Database
```bash
# Import file database.sql
mysql -u root -p situneo_digital < database.sql

# Atau melalui phpMyAdmin:
# 1. Buka phpMyAdmin
# 2. Pilih database 'situneo_digital'
# 3. Klik tab 'Import'
# 4. Pilih file 'database.sql'
# 5. Klik 'Go'
```

### 4. Konfigurasi Database
Edit file `config.php`:
```php
// Database Configuration
define('DB_HOST', 'localhost');      // Host database
define('DB_USER', 'root');           // Username MySQL Anda
define('DB_PASS', 'password_anda');  // Password MySQL Anda
define('DB_NAME', 'situneo_digital'); // Nama database
```

### 5. Set Permissions
```bash
# Berikan permission untuk folder uploads
chmod 755 uploads/
chmod 755 uploads/avatars/
chmod 755 uploads/services/
chmod 755 uploads/logos/

# Berikan permission untuk file config
chmod 644 config.php
chmod 644 .htaccess
```

### 6. Konfigurasi Email (Opsional)
Edit file `config.php` untuk SMTP:
```php
// Email Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your_email@gmail.com');
define('SMTP_PASSWORD', 'your_app_password');
define('SMTP_FROM_EMAIL', 'noreply@yourdomain.com');
define('SMTP_FROM_NAME', 'SITUNEO DIGITAL');
```

**Note untuk Gmail:**
- Aktifkan "Less secure app access" atau
- Gunakan "App Password" (Recommended)

### 7. Test Installation
```bash
# Menggunakan PHP Built-in Server
php -S localhost:8000

# Akses via browser
http://localhost:8000
```

**Atau menggunakan Apache/Nginx:**
- Letakkan folder di `/var/www/html/` atau `htdocs/`
- Akses melalui `http://localhost/situneo-digital/`

## 🔑 Default Login Credentials

### Admin Account
- **URL:** http://localhost/admin/
- **Email:** admin@situneo.my.id
- **Password:** Admin123!

### User Account
- **Email:** user@example.com
- **Password:** User123!

> ⚠️ **PENTING:** Segera ubah password default setelah login pertama kali!

## 🔧 Troubleshooting

### Error: "Connection failed"
```
Solution:
1. Pastikan MySQL service running
2. Cek username dan password di config.php
3. Pastikan database sudah dibuat
4. Cek host (biasanya 'localhost' atau '127.0.0.1')
```

### Error: "Permission denied"
```bash
Solution:
chmod -R 755 uploads/
chown -R www-data:www-data uploads/
```

### Error: "500 Internal Server Error"
```
Solution:
1. Cek file .htaccess
2. Pastikan mod_rewrite enabled di Apache
3. Cek error log di: /var/log/apache2/error.log
4. Set display_errors = On di php.ini untuk development
```

### Upload tidak berfungsi
```php
Solution:
1. Cek php.ini:
   upload_max_filesize = 10M
   post_max_size = 10M
2. Restart Apache/Nginx
3. Cek permissions folder uploads/
```

## ⚙️ Konfigurasi Apache

### Enable mod_rewrite
```bash
# Ubuntu/Debian
sudo a2enmod rewrite
sudo service apache2 restart

# CentOS/RHEL
sudo vim /etc/httpd/conf/httpd.conf
# Ubah "AllowOverride None" menjadi "AllowOverride All"
sudo systemctl restart httpd
```

### Virtual Host Configuration
```apache
<VirtualHost *:80>
    ServerName situneo.local
    DocumentRoot /var/www/html/situneo-digital
    
    <Directory /var/www/html/situneo-digital>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/situneo_error.log
    CustomLog ${APACHE_LOG_DIR}/situneo_access.log combined
</VirtualHost>
```

## 🔧 Konfigurasi Nginx

```nginx
server {
    listen 80;
    server_name situneo.local;
    root /var/www/html/situneo-digital;
    index index.php index.html;
    
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
    
    location ~ /\.ht {
        deny all;
    }
}
```

## 🛡️ Security Checklist

### Production Setup
- [ ] Ubah semua default passwords
- [ ] Set `display_errors = Off` di php.ini
- [ ] Enable HTTPS (SSL Certificate)
- [ ] Set strong database password
- [ ] Backup database secara rutin
- [ ] Update PHP dan MySQL ke versi terbaru
- [ ] Disable directory listing
- [ ] Protect config.php dan .htaccess
- [ ] Set proper file permissions
- [ ] Enable firewall

### File Permissions (Recommended)
```
Folders: 755
Files: 644
Config files: 600
Upload folders: 755
```

## 📱 Testing

### Test Admin Panel
1. Login sebagai admin
2. Test CRUD pada Services
3. Test User Management
4. Test Settings & Configuration

### Test Public Pages
1. Akses halaman services
2. Test filtering kategori
3. Test WhatsApp button
4. Test responsive design

### Test Authentication
1. Register new user
2. Login & logout
3. Forgot password
4. Reset password

## 🔄 Update & Maintenance

### Update Database
```sql
-- Backup database sebelum update
mysqldump -u root -p situneo_digital > backup_$(date +%Y%m%d).sql

-- Run migration scripts (jika ada)
mysql -u root -p situneo_digital < updates/migration_v2.sql
```

### Update Files
```bash
# Backup current installation
tar -czf backup_$(date +%Y%m%d).tar.gz .

# Pull latest updates
git pull origin main

# Clear cache if needed
php artisan cache:clear
```

## 📞 Support

Jika mengalami masalah saat instalasi:
- **Email:** support@situneo.my.id
- **WhatsApp:** +62 831-7386-8915
- **Website:** https://situneo.my.id

## 📄 License

Copyright © 2025 SITUNEO DIGITAL. All Rights Reserved.  
**NIB:** 20250-9261-4570-4515-5453

---

<div align="center">
  <strong>Made with ❤️ in Jakarta, Indonesia</strong><br>
  SITUNEO DIGITAL - Digital Harmony
</div>
