# 🚀 SITUNEO DIGITAL - Complete Web Application

![SITUNEO DIGITAL](https://img.shields.io/badge/SITUNEO-DIGITAL-FFB400?style=for-the-badge)
![PHP](https://img.shields.io/badge/PHP-8.0+-777BB4?style=for-the-badge&logo=php)
![MySQL](https://img.shields.io/badge/MySQL-8.0+-4479A1?style=for-the-badge&logo=mysql)
![Bootstrap](https://img.shields.io/badge/Bootstrap-5.3.3-7952B3?style=for-the-badge&logo=bootstrap)

> **NIB:** 20250-9261-4570-4515-5453  
> **Digital Agency Management System**

## 📋 Deskripsi

SITUNEO DIGITAL adalah sistem manajemen lengkap untuk digital agency yang menyediakan 26+ layanan digital profesional. Sistem ini mencakup authentication, user management, service management, admin panel, dan public-facing website.

## ✨ Fitur Utama

### 🔐 Authentication System
- ✅ Login & Register
- ✅ Forgot Password dengan Email Token
- ✅ Reset Password dengan Token Validation
- ✅ Session Management
- ✅ Role-based Access Control (User, Admin)

### 👥 User Management
- ✅ User Dashboard
- ✅ Profile Management
- ✅ Order History
- ✅ Invoice System
- ✅ Support Tickets

### 🛠️ Admin Panel
- ✅ Dashboard dengan Statistics
- ✅ User Management (CRUD)
- ✅ Service Management (CRUD)
  - 26+ Digital Services
  - Category Filtering
  - Status Management (Active/Inactive)
  - Dynamic Features
  - Image Upload
- ✅ Order Management
- ✅ Settings & Configuration
  - Company Information
  - Logo Upload
  - Email SMTP Settings
  - Backup & Security
- ✅ Reports & Analytics

### 🌐 Public Website
- ✅ Modern Landing Page
- ✅ Services Showcase (26 Layanan)
- ✅ Category Filtering
- ✅ Pricing Information
- ✅ WhatsApp Integration
- ✅ Contact Forms
- ✅ Portfolio/Demo Pages

### 🎨 Design Features
- ✅ Responsive Design (Mobile First)
- ✅ Network Background Animation
- ✅ Circuit Pattern Overlay
- ✅ Gradient Gold/Blue Theme
- ✅ Particle Effects
- ✅ Smooth Animations (AOS)
- ✅ Modern UI/UX

## 🗂️ Struktur File

```
SITUNEO_DIGITAL/
│
├── 📁 auth/
│   ├── login.php
│   ├── register.php
│   ├── forgot_password.php
│   ├── reset_password.php (✅ lanjutan43)
│   └── logout.php
│
├── 📁 admin/
│   ├── dashboard.php
│   ├── users.php
│   ├── services.php (✅ lanjutan45)
│   ├── orders.php
│   ├── settings.php (✅ lanjutan47)
│   └── reports.php
│
├── 📁 user/
│   ├── dashboard.php
│   ├── profile.php
│   ├── orders.php
│   ├── invoices.php
│   └── support.php
│
├── 📁 assets/
│   ├── 📁 css/
│   │   └── style.css (✅ lanjutan48)
│   ├── 📁 js/
│   │   └── main.js
│   └── 📁 images/
│
├── 📁 uploads/
│   ├── 📁 avatars/
│   ├── 📁 services/
│   └── 📁 logos/
│
├── 📄 index.php
├── 📄 services.php (✅ lanjutan46)
├── 📄 about.php
├── 📄 contact.php
├── 📄 pricing.php
├── 📄 portfolio.php
├── 📄 config.php
├── 📄 functions.php
├── 📄 database.sql
├── 📄 .htaccess
└── 📄 README.md
```

## 🔧 Teknologi yang Digunakan

### Backend
- **PHP 8.0+** - Server-side programming
- **MySQL 8.0+** - Database management
- **PDO/MySQLi** - Database connectivity

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Styling & animations
- **JavaScript (ES6+)** - Interactivity
- **Bootstrap 5.3.3** - UI framework
- **Bootstrap Icons 1.11.3** - Icon set
- **AOS (Animate On Scroll)** - Scroll animations

### Libraries & Tools
- **Inter & Plus Jakarta Sans** - Typography
- **Canvas API** - Network animations
- **CSS Grid & Flexbox** - Layout system

## 🚀 Instalasi

### Prasyarat
- PHP >= 8.0
- MySQL >= 8.0
- Apache/Nginx Web Server
- Composer (optional)

### Langkah Instalasi

1. **Clone Repository**
```bash
git clone https://github.com/username/situneo-digital.git
cd situneo-digital
```

2. **Buat Database**
```sql
CREATE DATABASE situneo_digital;
USE situneo_digital;
```

3. **Import Database**
```bash
mysql -u root -p situneo_digital < database.sql
```

4. **Konfigurasi Database**
Edit file `config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'your_password');
define('DB_NAME', 'situneo_digital');
```

5. **Set Permissions**
```bash
chmod 755 uploads/
chmod 644 config.php
```

6. **Jalankan Server**
```bash
# Menggunakan PHP Built-in Server
php -S localhost:8000

# Atau akses melalui Apache
http://localhost/situneo-digital
```

## 🎨 File Details

### 📄 **reset_password.php** (lanjutan43)
- **Lines:** 421
- **Features:**
  - Token validation dengan expiry check
  - Password strength indicator (weak/medium/strong)
  - Form validation dengan error handling
  - Toggle password visibility
  - Auto redirect setelah 3 detik
  - Responsive split layout design
  - Social media links

### 📄 **admin/services.php** (lanjutan45)
- **Lines:** 1471 (LARGEST FILE!)
- **Features:**
  - Filter by category & status
  - Search functionality with LIKE query
  - Pagination (12 items/page)
  - Add/Edit/Delete services
  - Dynamic feature management
  - Modal untuk service details
  - Network background animation
  - Service status toggle
  - Image URL upload

### 📄 **services.php** (lanjutan46)
- **Lines:** 877
- **Features:**
  - 26 Service cards dengan full details
  - Dynamic category filtering
  - Price badge dengan pulse animation
  - Feature list (max 5 shown + counter)
  - Delivery time & "Perfect for" info
  - WhatsApp CTA buttons
  - Calculator link
  - Network particle animation
  - Floating WhatsApp button
  - Footer dengan NIB

### 📄 **admin/settings.php** (lanjutan47)
- **Lines:** 1111
- **Features:**
  - Company information CRUD
  - Logo upload (max 2MB)
  - System configuration
  - SMTP email settings
  - Test email functionality
  - Backup settings
  - Security settings
  - Notification preferences
  - Network animation background

### 📄 **assets/css/style.css** (lanjutan48)
- **Lines:** 42
- **Features:**
  - Hero section gradient (#0d6efd → #0a58ca)
  - Card hover effects (translateY -5px)
  - Button rounded (50px radius)
  - Responsive breakpoints
  - Font weight utilities

## 🔑 Default Credentials

### Admin Account
- **Email:** admin@situneo.my.id
- **Password:** Admin123!

### User Account
- **Email:** user@example.com
- **Password:** User123!

> ⚠️ **PENTING:** Segera ubah password default setelah instalasi!

## 🎯 Fitur Services (26 Layanan)

### Website Development
1. Company Profile Website
2. Landing Page
3. Toko Online / E-Commerce
4. Sistem Booking/Reservasi
5. Web Portal Berita
6. Web Aplikasi Custom

### Digital Marketing
7. SEO Optimization
8. Google Ads Management
9. Facebook & Instagram Ads
10. Social Media Management
11. Content Marketing
12. Email Marketing

### Design Services
13. Logo Design
14. Brand Identity
15. UI/UX Design
16. Graphic Design
17. Video Editing
18. Animation

### Tech Solutions
19. Chatbot AI Development
20. WhatsApp Business API
21. CRM System
22. ERP System
23. Mobile App Development
24. API Integration
25. Cloud Migration
26. IT Consulting

## 🌈 Color Palette

```css
--primary-blue: #1E5C99
--dark-blue: #0F3057
--gold: #FFB400
--bright-gold: #FFD700
--white: #ffffff
--text-light: #e9ecef
--gradient-primary: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%)
--gradient-gold: linear-gradient(135deg, #FFD700 0%, #FFB400 100%)
```

## 📱 Contact

- **WhatsApp:** +62 831-7386-8915
- **Email:** support@situneo.my.id
- **Website:** https://situneo.my.id
- **Location:** Jakarta Timur, Indonesia

## 📄 License

Copyright © 2025 SITUNEO DIGITAL. All Rights Reserved.

**NIB:** 20250-9261-4570-4515-5453

---

## 🙏 Credits

- **Developer:** SITUNEO DIGITAL Team
- **Design:** Inter & Plus Jakarta Sans Fonts
- **Icons:** Bootstrap Icons
- **Animations:** AOS Library
- **Framework:** Bootstrap 5.3.3

---

<div align="center">
  <strong>Made with ❤️ in Jakarta, Indonesia</strong><br>
  SITUNEO DIGITAL - Digital Harmony
</div>
