# 🚀 SITUNEO DIGITAL - Installation Guide

## Prerequisites

Sebelum memulai instalasi, pastikan sistem Anda memiliki:

- **PHP** >= 7.4 (Recommended: PHP 8.0+)
- **MySQL** >= 5.7 atau **MariaDB** >= 10.3
- **Apache** dengan mod_rewrite enabled atau **Nginx**
- **Composer** (Optional, untuk dependency management)
- **Git** (untuk clone repository)

---

## 📥 Installation Steps

### 1. Clone atau Download Project

```bash
# Via Git
git clone https://github.com/yourusername/situneo-digital.git
cd situneo-digital

# Atau download ZIP dan extract
```

### 2. Setup Database

```bash
# Login ke MySQL
mysql -u root -p

# Create database
CREATE DATABASE situneo_digital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Create user (optional)
CREATE USER 'situneo_user'@'localhost' IDENTIFIED BY 'your_strong_password';
GRANT ALL PRIVILEGES ON situneo_digital.* TO 'situneo_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Import database
mysql -u root -p situneo_digital < database/situneo_digital.sql
```

### 3. Configure Database Connection

Edit file `database.php`:

```php
<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'situneo_user');
define('DB_PASS', 'your_strong_password');
define('DB_NAME', 'situneo_digital');
?>
```

### 4. Configure Application Settings

Edit file `config.php`:

```php
<?php
// Application settings
define('APP_NAME', 'SITUNEO DIGITAL');
define('APP_URL', 'https://yourdomain.com'); // Change to your domain
define('APP_ENV', 'production'); // development or production

// Email settings
define('FROM_EMAIL', 'noreply@yourdomain.com');
define('FROM_NAME', 'SITUNEO DIGITAL');
define('SUPPORT_EMAIL', 'support@yourdomain.com');

// Company info
define('COMPANY_PHONE', '+6283173868915');
define('COMPANY_ADDRESS', 'Jakarta Timur, Indonesia');
?>
```

### 5. Set File Permissions

```bash
# Set proper permissions
chmod 755 -R ./
chmod 777 assets/uploads/
chmod 777 assets/cache/
chmod 777 logs/

# For production (more secure)
chown -R www-data:www-data ./
chmod 750 -R ./
chmod 770 assets/uploads/
chmod 770 assets/cache/
```

### 6. Configure Web Server

#### Apache (.htaccess)

File `.htaccess` sudah included. Pastikan mod_rewrite enabled:

```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

Apache VirtualHost configuration:

```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com
    DocumentRoot /var/www/situneo-digital
    
    <Directory /var/www/situneo-digital>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/situneo_error.log
    CustomLog ${APACHE_LOG_DIR}/situneo_access.log combined
</VirtualHost>
```

#### Nginx

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    root /var/www/situneo-digital;
    index index.php index.html;
    
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
    
    location ~ /\.ht {
        deny all;
    }
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-XSS-Protection "1; mode=block";
    add_header X-Content-Type-Options "nosniff";
}
```

### 7. Configure PHP Settings

Edit `php.ini`:

```ini
upload_max_filesize = 10M
post_max_size = 10M
max_execution_time = 300
memory_limit = 256M
```

### 8. Install Dependencies (Optional)

Jika menggunakan Composer:

```bash
composer install --no-dev
```

### 9. Setup Cron Jobs (Optional)

Untuk automated tasks seperti email reminders, cleanup, dll:

```bash
# Edit crontab
crontab -e

# Add these lines
# Send daily email reports
0 9 * * * php /var/www/situneo-digital/cron/daily_report.php

# Cleanup old sessions
0 0 * * * php /var/www/situneo-digital/cron/cleanup.php

# Backup database
0 2 * * * php /var/www/situneo-digital/cron/backup_db.php
```

### 10. Test Installation

```bash
# Access website
http://yourdomain.com

# Default admin login
Email: admin@situneo.my.id
Password: admin123

# IMPORTANT: Change default password immediately!
```

---

## 🔧 Post-Installation Configuration

### 1. Change Default Admin Password

1. Login dengan kredensial default
2. Go to Profile Settings
3. Change password
4. Enable Two-Factor Authentication (recommended)

### 2. Setup Email (SMTP)

Edit `config.php`:

```php
// SMTP Settings
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-app-password');
define('SMTP_SECURE', 'tls');
```

### 3. Setup WhatsApp Integration

1. Go to Admin Panel > Settings
2. Enter WhatsApp Business API credentials
3. Test connection

### 4. Configure Payment Gateway (Optional)

```php
// Midtrans
define('MIDTRANS_CLIENT_KEY', 'your-client-key');
define('MIDTRANS_SERVER_KEY', 'your-server-key');
define('MIDTRANS_IS_PRODUCTION', false);

// Xendit
define('XENDIT_API_KEY', 'your-api-key');
```

### 5. Setup Backup Schedule

```bash
# Manual backup
php cron/backup_db.php

# Automated backup (already in cron)
# Backups saved to: /backups/
```

### 6. Configure Social Media Login (Optional)

```php
// Google OAuth
define('GOOGLE_CLIENT_ID', 'your-client-id');
define('GOOGLE_CLIENT_SECRET', 'your-client-secret');
define('GOOGLE_REDIRECT_URI', APP_URL . '/auth/google_callback.php');

// Facebook OAuth
define('FACEBOOK_APP_ID', 'your-app-id');
define('FACEBOOK_APP_SECRET', 'your-app-secret');
define('FACEBOOK_REDIRECT_URI', APP_URL . '/auth/facebook_callback.php');
```

---

## 🔐 Security Checklist

- [ ] Change default admin password
- [ ] Set strong database password
- [ ] Configure SSL certificate (HTTPS)
- [ ] Set proper file permissions
- [ ] Disable directory listing
- [ ] Configure firewall rules
- [ ] Enable fail2ban for brute force protection
- [ ] Setup regular backups
- [ ] Configure security headers
- [ ] Test for SQL injection vulnerabilities
- [ ] Test for XSS vulnerabilities
- [ ] Enable CSRF protection
- [ ] Configure rate limiting
- [ ] Setup monitoring and alerts

---

## 🐛 Troubleshooting

### Issue: Cannot connect to database

**Solution:**
```bash
# Check MySQL service
sudo systemctl status mysql

# Check credentials in database.php
# Test connection
mysql -u situneo_user -p situneo_digital
```

### Issue: 500 Internal Server Error

**Solution:**
```bash
# Check error logs
tail -f /var/log/apache2/situneo_error.log
# or
tail -f /var/log/nginx/error.log

# Check PHP error log
tail -f /var/log/php/error.log

# Enable error display (development only)
# In config.php:
ini_set('display_errors', 1);
error_reporting(E_ALL);
```

### Issue: File upload not working

**Solution:**
```bash
# Check directory permissions
ls -la assets/uploads/

# Set proper permissions
chmod 777 assets/uploads/

# Check PHP upload settings
php -i | grep upload
```

### Issue: Email not sending

**Solution:**
1. Check SMTP settings in config.php
2. Test SMTP connection
3. Check spam folder
4. Verify email credentials
5. Check firewall blocking port 587/465

### Issue: Blank page or white screen

**Solution:**
```bash
# Enable error display
# Edit config.php or php.ini
display_errors = On

# Check PHP logs
tail -f /var/log/php/error.log

# Clear cache
rm -rf assets/cache/*
```

---

## 📊 Performance Optimization

### 1. Enable OPcache

```ini
# In php.ini
opcache.enable=1
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=10000
opcache.revalidate_freq=60
```

### 2. Enable Gzip Compression

Apache (.htaccess):
```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>
```

Nginx:
```nginx
gzip on;
gzip_types text/plain text/css application/json application/javascript text/xml application/xml;
```

### 3. Setup Redis Cache (Optional)

```bash
# Install Redis
sudo apt-get install redis-server

# Install PHP Redis extension
sudo apt-get install php-redis

# Configure in config.php
define('REDIS_HOST', '127.0.0.1');
define('REDIS_PORT', 6379);
```

### 4. Setup CDN (Optional)

1. Upload static files (CSS, JS, images) to CDN
2. Update URLs in header.php
3. Configure CDN caching rules

---

## 🔄 Update Guide

### Manual Update

```bash
# Backup current installation
cp -r situneo-digital situneo-digital-backup
mysqldump -u root -p situneo_digital > situneo_backup.sql

# Pull latest changes
git pull origin main

# Run database migrations
php migrations/migrate.php

# Clear cache
rm -rf assets/cache/*
```

### Automatic Update (Coming Soon)

Dashboard > Settings > Updates > Check for Updates

---

## 📞 Support

Jika mengalami masalah saat instalasi:

1. Check documentation: `/docs/`
2. Search in GitHub Issues
3. Contact support:
   - Email: support@situneo.my.id
   - WhatsApp: +62 831-7386-8915
   - Website: https://situneo.my.id

---

**Installation guide ini akan terus diupdate. Last updated: 2025**
