<?php
/**
 * ========================================
 * SITUNEO DIGITAL - Main Configuration
 * NIB: 20250-9261-4570-4515-5453
 * ========================================
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Application Settings
define('APP_NAME', 'SITUNEO DIGITAL');
define('APP_URL', 'https://situneo.my.id');
define('APP_ENV', 'production'); // development or production

// Company Information
define('COMPANY_NAME', 'SITUNEO DIGITAL');
define('COMPANY_NIB', '20250-9261-4570-4515-5453');
define('COMPANY_PHONE', '+6283173868915');
define('COMPANY_EMAIL', 'support@situneo.my.id');
define('COMPANY_ADDRESS', 'Jakarta Timur, Indonesia');

// Email Settings
define('FROM_EMAIL', 'noreply@situneo.my.id');
define('FROM_NAME', 'SITUNEO DIGITAL');
define('SUPPORT_EMAIL', 'support@situneo.my.id');

// SMTP Settings (if using SMTP for email)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-app-password');
define('SMTP_SECURE', 'tls'); // tls or ssl

// Security Settings
define('MIN_PASSWORD_LENGTH', 8);
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes

// User Roles
define('ROLE_USER', 1);
define('ROLE_ADMIN', 2);
define('ROLE_SUPER_ADMIN', 3);

// File Upload Settings
define('MAX_UPLOAD_SIZE', 5242880); // 5MB in bytes
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_DOC_TYPES', ['pdf', 'doc', 'docx', 'xls', 'xlsx']);

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Error Reporting (set to 0 in production)
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Include database configuration
require_once 'database.php';

// Include authentication functions
require_once 'includes/auth_functions.php';

/**
 * Helper function to sanitize input
 */
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Helper function to format currency
 */
function format_currency($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

/**
 * Helper function to format date
 */
function format_date($date, $format = 'd M Y') {
    return date($format, strtotime($date));
}

/**
 * Helper function to get time ago
 */
function time_ago($datetime) {
    $timestamp = strtotime($datetime);
    $now = time();
    $diff = $now - $timestamp;
    
    if ($diff < 60) {
        return 'Baru saja';
    } elseif ($diff < 3600) {
        return floor($diff / 60) . ' menit yang lalu';
    } elseif ($diff < 86400) {
        return floor($diff / 3600) . ' jam yang lalu';
    } elseif ($diff < 604800) {
        return floor($diff / 86400) . ' hari yang lalu';
    } else {
        return date('d M Y', $timestamp);
    }
}

/**
 * Helper function to redirect
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Helper function to set flash message
 */
function set_flash($type, $message) {
    $_SESSION['flash_type'] = $type;
    $_SESSION['flash_message'] = $message;
}

/**
 * Helper function to get and clear flash message
 */
function get_flash() {
    if (isset($_SESSION['flash_message'])) {
        $flash = [
            'type' => $_SESSION['flash_type'],
            'message' => $_SESSION['flash_message']
        ];
        unset($_SESSION['flash_type']);
        unset($_SESSION['flash_message']);
        return $flash;
    }
    return null;
}
?>
