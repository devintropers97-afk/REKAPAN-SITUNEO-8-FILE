# SITUNEO DIGITAL - Complete Digital Agency Platform

![SITUNEO DIGITAL](https://ui-avatars.com/api/?name=SITUNEO&size=200&background=FFB400&color=0F3057&bold=true)

## 📋 Deskripsi Project

**SITUNEO DIGITAL** adalah platform lengkap untuk digital agency yang menyediakan berbagai layanan digital marketing, pembuatan website, SEO, dan konsultasi digital. Project ini dibangun dengan PHP native, MySQL, dan Bootstrap 5.

**NIB:** 20250-9261-4570-4515-5453

---

## 🚀 Fitur Utama

### Public Pages
- ✅ **Homepage** - Landing page dengan animasi dan design modern
- ✅ **About Us** - Profil perusahaan, visi misi, tim, dan timeline
- ✅ **Services** - Katalog layanan lengkap dengan 26+ layanan
- ✅ **Pricing** - Paket harga yang jelas dan transparan
- ✅ **Portfolio/Demo** - Showcase demo website
- ✅ **Calculator** - Kalkulator harga otomatis dengan keranjang belanja
- ✅ **Contact** - Form kontak dan informasi lengkap
- ✅ **Blog** - Platform blog untuk konten marketing

### Authentication System
- ✅ **Register** - Pendaftaran user dengan email verification
- ✅ **Login** - Sistem login dengan remember me
- ✅ **Email Verification** - Verifikasi email otomatis
- ✅ **Forgot Password** - Reset password via email
- ✅ **Social Login** - Login dengan Google/Facebook (optional)

### User Dashboard
- ✅ **Profile Management** - Edit profil dan foto
- ✅ **Order History** - Riwayat pesanan lengkap
- ✅ **Order Tracking** - Tracking status pesanan
- ✅ **Notifications** - Sistem notifikasi real-time
- ✅ **Support Tickets** - Sistem tiket dukungan

### Admin Panel
- ✅ **Dashboard** - Overview statistik lengkap
- ✅ **User Management** - Kelola semua user
- ✅ **Order Management** - Kelola pesanan
- ✅ **Service Management** - Kelola layanan
- ✅ **Content Management** - Kelola konten website
- ✅ **Settings** - Pengaturan sistem
- ✅ **Activity Logs** - Log aktivitas user

### Advanced Features
- ✅ **Referral System** - Sistem referral dengan kode unik
- ✅ **Commission System** - Sistem komisi untuk affiliate
- ✅ **Multi-Language** - Support Bahasa Indonesia & English
- ✅ **SEO Optimized** - Meta tags dan sitemap otomatis
- ✅ **Mobile Responsive** - Fully responsive di semua device
- ✅ **PWA Ready** - Progressive Web App support
- ✅ **WhatsApp Integration** - Integrasi WhatsApp Business

---

## 🛠️ Tech Stack

### Backend
- **PHP 7.4+** - Server-side programming
- **MySQL 5.7+** - Database management
- **Apache/Nginx** - Web server

### Frontend
- **HTML5** - Markup language
- **CSS3** - Styling dengan custom animations
- **JavaScript ES6+** - Interactive features
- **Bootstrap 5.3.3** - UI Framework
- **Bootstrap Icons 1.11.3** - Icon library
- **AOS 2.3.1** - Animation on scroll library

### Libraries & Tools
- **PHPMailer** - Email sending
- **Chart.js** - Data visualization
- **DataTables** - Advanced table features
- **SweetAlert2** - Beautiful alerts
- **Moment.js** - Date/time handling

---

## 📁 Struktur Project

```
SITUNEO-DIGITAL/
├── index.php                 # Homepage
├── about.php                 # About Us page
├── services.php              # Services catalog
├── pricing.php               # Pricing packages
├── portfolio.php             # Portfolio/Demo page
├── calculator.php            # Price calculator
├── contact.php              # Contact page
├── blog.php                 # Blog listing
├── blog_detail.php          # Blog detail page
├── config.php               # Main configuration
├── database.php             # Database configuration
│
├── auth/
│   ├── login.php            # Login page
│   ├── register.php         # Registration page
│   ├── verify.php           # Email verification
│   ├── forgot_password.php  # Forgot password
│   ├── reset_password.php   # Reset password
│   └── logout.php           # Logout handler
│
├── dashboard/
│   ├── index.php            # User dashboard
│   ├── profile.php          # Profile management
│   ├── orders.php           # Order history
│   ├── tickets.php          # Support tickets
│   └── notifications.php    # Notifications
│
├── admin/
│   ├── dashboard.php        # Admin dashboard
│   ├── users.php            # User management
│   ├── add_user_process.php # Add user handler
│   ├── orders.php           # Order management
│   ├── add_order_process.php # Add order handler
│   ├── services.php         # Service management
│   ├── projects.php         # Project management
│   ├── inquiries.php        # Inquiry management
│   ├── settings.php         # System settings
│   └── activities.php       # Activity logs
│
├── includes/
│   ├── header.php           # Global header
│   ├── footer.php           # Global footer
│   ├── navbar.php           # Navigation bar
│   └── auth_functions.php   # Authentication functions
│
├── assets/
│   ├── css/
│   │   └── style.css        # Custom styles
│   ├── js/
│   │   └── main.js          # Custom scripts
│   ├── img/
│   │   └── (images)
│   └── uploads/
│       └── (user uploads)
│
├── api/
│   ├── services.php         # Services API
│   ├── orders.php           # Orders API
│   └── user.php             # User API
│
└── vendor/
    └── (third-party libraries)
```

---

## 💾 Database Schema

### Tables Overview

1. **users** - Data pengguna
2. **services** - Katalog layanan
3. **orders** - Data pesanan
4. **projects** - Data proyek
5. **inquiries** - Pertanyaan dari contact form
6. **referrals** - Data referral
7. **commissions** - Data komisi
8. **activity_logs** - Log aktivitas
9. **settings** - Pengaturan sistem
10. **blog_posts** - Artikel blog
11. **notifications** - Notifikasi user

### Database Configuration
```php
DB_HOST: localhost
DB_USER: nrrskfvk_user_situneo_digital
DB_PASS: Devin1922$
DB_NAME: nrrskfvk_situneo_digital
```

---

## 🔧 Installation Guide

### Requirements
- PHP >= 7.4
- MySQL >= 5.7
- Apache/Nginx web server
- Composer (optional)

### Step 1: Clone Repository
```bash
git clone https://github.com/yourusername/situneo-digital.git
cd situneo-digital
```

### Step 2: Database Setup
```bash
# Import database
mysql -u root -p situneo_digital < database/situneo_digital.sql

# Or create manually and import via phpMyAdmin
```

### Step 3: Configuration
```php
# Edit database.php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('DB_NAME', 'situneo_digital');

# Edit config.php
define('APP_NAME', 'SITUNEO DIGITAL');
define('APP_URL', 'https://yourdomain.com');
define('FROM_EMAIL', 'noreply@yourdomain.com');
```

### Step 4: Set Permissions
```bash
chmod 755 -R ./
chmod 777 assets/uploads/
chmod 777 assets/cache/
```

### Step 5: Access Website
```
http://localhost/situneo-digital
```

### Default Admin Login
```
Email: admin@situneo.my.id
Password: admin123
```

---

## 🎨 Design Features

### Color Scheme
- **Primary Blue**: #1E5C99
- **Dark Blue**: #0F3057
- **Gold**: #FFB400
- **Bright Gold**: #FFD700
- **White**: #FFFFFF
- **Text Light**: #E9ECEF

### Typography
- **Primary Font**: Inter
- **Heading Font**: Plus Jakarta Sans

### Animations
- AOS (Animate On Scroll)
- Custom CSS animations
- Network background particles
- Circuit pattern animation

### Responsive Breakpoints
- Mobile: < 576px
- Tablet: 576px - 768px
- Desktop: 768px - 992px
- Large Desktop: > 992px

---

## 📱 API Documentation

### Services API
```php
GET /api/services.php
POST /api/services.php
PUT /api/services.php?id={id}
DELETE /api/services.php?id={id}
```

### Orders API
```php
GET /api/orders.php
POST /api/orders.php
PUT /api/orders.php?id={id}
DELETE /api/orders.php?id={id}
```

### User API
```php
GET /api/user.php
PUT /api/user.php
```

---

## 🔐 Security Features

1. **Password Hashing** - Bcrypt algorithm
2. **SQL Injection Prevention** - Prepared statements
3. **XSS Protection** - Input sanitization
4. **CSRF Protection** - Token validation
5. **Email Verification** - Prevent fake accounts
6. **Rate Limiting** - Prevent brute force
7. **Session Management** - Secure session handling
8. **File Upload Validation** - Prevent malicious files

---

## 📊 Performance Optimization

1. **Database Indexing** - Optimized queries
2. **Image Optimization** - Compressed images
3. **CSS/JS Minification** - Reduced file size
4. **Browser Caching** - Faster page load
5. **Lazy Loading** - Images and content
6. **CDN Integration** - Bootstrap & libraries
7. **Gzip Compression** - Server-side compression

---

## 🌐 SEO Features

1. **Meta Tags** - Dynamic meta descriptions
2. **Open Graph** - Social media sharing
3. **Sitemap.xml** - Automatic generation
4. **Robots.txt** - Search engine directives
5. **Schema Markup** - Structured data
6. **Canonical URLs** - Prevent duplicate content
7. **Alt Tags** - Image SEO
8. **URL Structure** - Clean and semantic

---

## 📞 Support & Contact

- **Website**: https://situneo.my.id
- **Email**: support@situneo.my.id
- **WhatsApp**: +62 831-7386-8915
- **Address**: Jakarta Timur, Indonesia

### Social Media
- Instagram: @situneodigital
- Facebook: /situneodigital
- LinkedIn: /company/situneodigital
- TikTok: @situneodigital

---

## 📝 License

Copyright © 2025 SITUNEO DIGITAL. All rights reserved.

**NIB:** 20250-9261-4570-4515-5453

This project is proprietary and confidential. Unauthorized copying, distribution, or use of this software, via any medium, is strictly prohibited.

---

## 👥 Contributors

- **Devin Prasetyo Hermawan** - CEO & Founder
- **Budi Santoso** - CTO
- **Sarah Wijaya** - Creative Director
- **Maya Putri** - Head of Digital Marketing

---

## 📈 Changelog

### Version 2.0.0 (Current)
- ✅ Complete admin panel
- ✅ User dashboard with order tracking
- ✅ Calculator with shopping cart
- ✅ Advanced referral system
- ✅ Commission tracking
- ✅ Activity logging
- ✅ Email notifications
- ✅ WhatsApp integration

### Version 1.0.0
- ✅ Basic website structure
- ✅ Authentication system
- ✅ Service catalog
- ✅ Contact form
- ✅ Blog system

---

## 🔮 Roadmap

### Q1 2025
- [ ] Payment Gateway Integration (Midtrans, Xendit)
- [ ] Live Chat Support
- [ ] Mobile App (Flutter)
- [ ] API for third-party integration

### Q2 2025
- [ ] AI Chatbot
- [ ] Advanced Analytics Dashboard
- [ ] Multi-currency support
- [ ] Invoice automation

### Q3 2025
- [ ] CRM Integration
- [ ] Project Management Tool
- [ ] Time Tracking System
- [ ] Client Portal

### Q4 2025
- [ ] White Label Solution
- [ ] Marketplace for services
- [ ] Affiliate Dashboard
- [ ] Advanced Reporting

---

## 💡 Tips & Best Practices

### For Developers
1. Always use prepared statements for database queries
2. Sanitize user inputs
3. Follow PSR coding standards
4. Comment your code
5. Use version control (Git)
6. Test on multiple browsers

### For Administrators
1. Regular database backups
2. Keep system updated
3. Monitor activity logs
4. Review security settings
5. Optimize images before upload
6. Use strong passwords

### For Users
1. Enable two-factor authentication
2. Keep profile information updated
3. Check notifications regularly
4. Report suspicious activity
5. Use referral code to earn commission

---

## 🆘 Troubleshooting

### Common Issues

**Issue**: Cannot login
- Solution: Clear browser cache and cookies
- Check if email is verified
- Try password reset

**Issue**: Email not received
- Solution: Check spam folder
- Verify SMTP settings
- Contact support

**Issue**: Upload failed
- Solution: Check file size (max 5MB)
- Verify file type allowed
- Check upload directory permissions

**Issue**: 500 Internal Server Error
- Solution: Check error logs
- Verify PHP version
- Check .htaccess configuration

---

## 📚 Documentation

Full documentation available at:
- User Guide: `/docs/user-guide.pdf`
- Admin Manual: `/docs/admin-manual.pdf`
- API Reference: `/docs/api-reference.pdf`
- Developer Guide: `/docs/developer-guide.pdf`

---

## 🙏 Acknowledgments

Special thanks to:
- Bootstrap team for the amazing framework
- Font Awesome for icons
- AOS library for smooth animations
- All open-source contributors

---

**Made with ❤️ in Jakarta, Indonesia**

*SITUNEO DIGITAL - Digital Harmony*
