-- SITUNEO DIGITAL Database Schema
-- NIB: 20250-9261-4570-4515-5453

CREATE DATABASE IF NOT EXISTS situneo_digital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE situneo_digital;

-- Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    role TINYINT DEFAULT 0,
    avatar VARCHAR(255),
    email_verified TINYINT DEFAULT 0,
    verification_token VARCHAR(255),
    remember_token VARCHAR(255),
    remember_expiry INT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Services Table  
CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    category VARCHAR(100),
    price_start DECIMAL(15,2) NOT NULL,
    price_end DECIMAL(15,2),
    image VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Orders Table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    service_id INT NOT NULL,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
    total_amount DECIMAL(15,2) NOT NULL,
    requirements TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (service_id) REFERENCES services(id)
) ENGINE=InnoDB;

-- Activity Logs
CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- Password Resets
CREATE TABLE password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expiry INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default Admin (password: admin123)
INSERT INTO users (name, email, password, role, email_verified) VALUES 
('Administrator', 'admin@situneo.my.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 1);

-- 26 Services
INSERT INTO services (name, slug, description, category, price_start, price_end, status) VALUES
('Website Development', 'website-development', 'Website profesional responsif dan SEO-friendly', 'Web Development', 2500000, 50000000, 'active'),
('SEO & Digital Marketing', 'seo-marketing', 'Optimasi mesin pencari dan strategi marketing', 'Digital Marketing', 3000000, 25000000, 'active'),
('E-Commerce Solutions', 'ecommerce', 'Solusi e-commerce lengkap dengan payment gateway', 'Web Development', 15000000, 100000000, 'active'),
('Mobile App Development', 'mobile-app', 'Aplikasi mobile Android dan iOS', 'Mobile Development', 25000000, 150000000, 'active'),
('UI/UX Design', 'ui-ux-design', 'Desain antarmuka dan pengalaman pengguna', 'Design', 5000000, 30000000, 'active'),
('Brand Identity', 'brand-identity', 'Pengembangan identitas brand yang kuat', 'Design', 7500000, 40000000, 'active'),
('Social Media Management', 'social-media', 'Pengelolaan media sosial profesional', 'Digital Marketing', 2000000, 15000000, 'active'),
('Content Marketing', 'content-marketing', 'Strategi konten yang efektif', 'Digital Marketing', 3500000, 20000000, 'active'),
('Email Marketing', 'email-marketing', 'Kampanye email marketing terukur', 'Digital Marketing', 2000000, 10000000, 'active'),
('Google Ads Management', 'google-ads', 'Pengelolaan kampanye Google Ads', 'Digital Marketing', 5000000, 30000000, 'active'),
('Facebook Ads', 'facebook-ads', 'Kampanye Facebook Ads profesional', 'Digital Marketing', 4000000, 25000000, 'active'),
('Instagram Marketing', 'instagram-marketing', 'Strategi marketing Instagram', 'Digital Marketing', 3500000, 20000000, 'active'),
('Video Production', 'video-production', 'Produksi video profesional', 'Media Production', 8000000, 50000000, 'active'),
('Photography', 'photography', 'Jasa fotografi profesional', 'Media Production', 5000000, 30000000, 'active'),
('Graphic Design', 'graphic-design', 'Desain grafis kreatif', 'Design', 3000000, 20000000, 'active'),
('Logo Design', 'logo-design', 'Desain logo memorable', 'Design', 2500000, 15000000, 'active'),
('Business Consulting', 'business-consulting', 'Konsultasi bisnis dan strategi', 'Consulting', 10000000, 100000000, 'active'),
('IT Support', 'it-support', 'Dukungan IT komprehensif', 'Technology', 5000000, 40000000, 'active'),
('Cloud Services', 'cloud-services', 'Implementasi layanan cloud', 'Technology', 10000000, 100000000, 'active'),
('Cybersecurity', 'cybersecurity', 'Solusi keamanan siber', 'Technology', 15000000, 80000000, 'active'),
('Data Analytics', 'data-analytics', 'Analisis data mendalam', 'Technology', 12000000, 60000000, 'active'),
('CRM Implementation', 'crm', 'Implementasi sistem CRM', 'Technology', 15000000, 80000000, 'active'),
('ERP Systems', 'erp', 'Sistem ERP terintegrasi', 'Technology', 50000000, 500000000, 'active'),
('Automation & AI', 'automation-ai', 'Solusi otomasi dan AI', 'Technology', 20000000, 200000000, 'active'),
('Blockchain Solutions', 'blockchain', 'Solusi blockchain', 'Technology', 30000000, 300000000, 'active'),
('IoT Integration', 'iot', 'Integrasi Internet of Things', 'Technology', 25000000, 200000000, 'active');
