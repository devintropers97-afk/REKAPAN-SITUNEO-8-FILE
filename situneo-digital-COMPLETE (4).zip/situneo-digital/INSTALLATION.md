# Installation Guide - SITUNEO DIGITAL

## Requirements
- PHP 7.4+
- MySQL 5.7+
- Apache/Nginx

## Steps
1. Extract files
2. Import database/schema.sql  
3. Configure config/config.php
4. Set permissions: chmod 755 uploads/ cache/ logs/
5. Access via browser

## Default Login
Email: admin@situneo.my.id
Password: admin123

⚠️ Change password after first login!

For details see: docs-GITHUB_GUIDE.md
