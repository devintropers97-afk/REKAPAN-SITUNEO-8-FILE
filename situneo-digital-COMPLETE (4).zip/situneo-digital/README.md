# 🌟 SITUNEO DIGITAL - Complete Digital Services Platform

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-777BB4?logo=php)
![MySQL](https://img.shields.io/badge/MySQL-5.7%2B-4479A1?logo=mysql)
![Bootstrap](https://img.shields.io/badge/Bootstrap-5.3.3-7952B3?logo=bootstrap)
![License](https://img.shields.io/badge/license-Proprietary-red.svg)
![Status](https://img.shields.io/badge/status-Production%20Ready-success)

<p align="center">
  <img src="https://situneo.my.id/logo" alt="SITUNEO DIGITAL Logo" width="150">
</p>

<h3 align="center">Digital Harmony for a Modern World</h3>

<p align="center">
  <strong>26 Professional Digital Services in One Comprehensive Platform</strong>
</p>

<p align="center">
  <a href="#features">Features</a> •
  <a href="#installation">Installation</a> •
  <a href="#documentation">Documentation</a> •
  <a href="#demo">Demo</a> •
  <a href="#support">Support</a>
</p>

---

## 📖 About

**SITUNEO DIGITAL** is a complete digital services management platform designed to help businesses grow in the modern era. Built with PHP, MySQL, and Bootstrap, it provides a comprehensive solution for managing digital service operations.

### Business Information
- **Company**: SITUNEO DIGITAL
- **NIB**: 20250-9261-4570-4515-5453
- **Website**: [https://situneo.my.id](https://situneo.my.id)
- **Email**: info@situneo.my.id
- **Phone**: +62 831-7386-8915

---

## ✨ Features

### 🎯 Core Features
- ✅ **User Authentication System** - Complete login, registration, email verification
- ✅ **User Dashboard** - Profile management, order tracking, invoice generation
- ✅ **Order Management** - Create, track, and manage service orders
- ✅ **Invoice System** - Automatic invoice generation with print/PDF export
- ✅ **Admin Panel** - Comprehensive administrative interface
- ✅ **Service Catalog** - 26 pre-configured digital services
- ✅ **Multi-language** - Indonesian and English support
- ✅ **Email System** - Automated notifications and templates

### 🛡️ Security Features
- 🔒 Password hashing (bcrypt)
- 🔒 SQL injection protection (prepared statements)
- 🔒 XSS protection
- 🔒 CSRF protection
- 🔒 Session security
- 🔒 Email verification
- 🔒 Role-based access control

### 🎨 Design Features
- 📱 Fully responsive (mobile-first)
- ✨ Network background animation (Canvas API)
- ✨ Smooth scroll animations (AOS)
- ✨ Modern gradient color scheme
- ✨ Professional UI/UX
- ✨ Bootstrap 5.3.3

---

## 🚀 Quick Start

### Prerequisites
```bash
PHP 7.4+
MySQL 5.7+ or MariaDB 10.2+
Apache/Nginx with mod_rewrite
```

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/situneo-digital.git
cd situneo-digital
```

2. **Create database**
```sql
CREATE DATABASE situneo_digital CHARACTER SET utf8mb4;
```

3. **Import database schema**
```bash
mysql -u root -p situneo_digital < database/schema.sql
```

4. **Configure application**
```bash
cp config/config.example.php config/config.php
# Edit config/config.php with your settings
```

5. **Set permissions**
```bash
chmod 755 uploads/
chmod 755 cache/
chmod 755 logs/
```

6. **Access your application**
```
http://yourdomain.com
```

Default admin credentials:
- Email: `admin@situneo.my.id`
- Password: `admin123`

⚠️ **Change the password immediately after first login!**

---

## 📂 Project Structure

```
situneo-digital/
├── config/              # Configuration files
├── includes/            # Helper functions
├── database/            # Database schema
├── auth/                # Authentication pages
├── admin/               # Admin panel
├── pages/               # Public pages
├── assets/              # CSS, JS, images
├── uploads/             # User uploads
├── cache/               # Cache directory
└── logs/                # Log files
```

See [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) for detailed information.

---

## 📚 Documentation

- 📖 [Installation Guide](INSTALLATION.md) - Detailed setup instructions
- 🏗️ [Project Structure](PROJECT_STRUCTURE.md) - Architecture overview
- 📝 [Changelog](CHANGELOG.md) - Version history
- 📜 [License](LICENSE.md) - License information

---

## 🎯 26 Digital Services

### Web Development
- Website Development
- E-Commerce Solutions
- UI/UX Design

### Mobile Development
- Mobile App Development

### Digital Marketing
- SEO & Digital Marketing
- Social Media Management
- Content Marketing
- Email Marketing
- Google Ads Management
- Facebook Ads
- Instagram Marketing

### Design
- Brand Identity
- Graphic Design
- Logo Design

### Media Production
- Video Production
- Photography

### Technology
- Cloud Services
- Cybersecurity
- Data Analytics
- IT Support
- CRM Implementation
- ERP Systems
- Automation & AI
- Blockchain Solutions
- IoT Integration

### Consulting
- Business Consulting

---

## 🖼️ Screenshots

### Homepage
<img src="docs/screenshots/homepage.png" alt="Homepage" width="100%">

### Dashboard
<img src="docs/screenshots/dashboard.png" alt="Dashboard" width="100%">

### Admin Panel
<img src="docs/screenshots/admin.png" alt="Admin Panel" width="100%">

---

## 🛠️ Built With

- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+ / MariaDB 10.2+
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Framework**: Bootstrap 5.3.3
- **Icons**: Bootstrap Icons 1.11.3
- **Animations**: AOS (Animate On Scroll)
- **Fonts**: Inter, Plus Jakarta Sans

---

## 📊 Database Schema

### Tables
- `users` - User accounts and profiles
- `services` - Service catalog (26 services)
- `orders` - Customer orders
- `activity_logs` - User activity tracking
- `password_resets` - Password reset tokens

---

## 🔧 Configuration

Edit `config/config.php`:

```php
// Database
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'situneo_digital');

// Application
define('APP_NAME', 'SITUNEO DIGITAL');
define('APP_URL', 'https://yourdomain.com');

// Email
define('FROM_EMAIL', 'noreply@yourdomain.com');
define('SMTP_HOST', 'smtp.gmail.com');
```

---

## 🧪 Testing

```bash
# Run local development server
php -S localhost:8000

# Access application
http://localhost:8000
```

---

## 📈 Roadmap

### Version 1.1.0 (Planned)
- [ ] Payment gateway integration (Midtrans)
- [ ] Real-time notifications
- [ ] Advanced analytics with charts
- [ ] Customer review system
- [ ] Live chat support

### Version 2.0.0 (Future)
- [ ] Mobile app (React Native)
- [ ] API documentation
- [ ] CRM features
- [ ] Project management module

See [CHANGELOG.md](CHANGELOG.md) for details.

---

## 🤝 Contributing

We welcome contributions! Please follow these steps:

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📝 License

This project is licensed under a **Proprietary License** - see the [LICENSE.md](LICENSE.md) file for details.

**Copyright © 2025 SITUNEO DIGITAL. All rights reserved.**
**NIB: 20250-9261-4570-4515-5453**

For commercial licensing inquiries, contact: info@situneo.my.id

---

## 👥 Authors

- **SITUNEO DIGITAL Team** - *Initial work and maintenance*

---

## 🙏 Acknowledgments

- Bootstrap team for the amazing framework
- All open-source contributors
- Our clients for their trust and feedback

---

## 📞 Support

### Need Help?

- 📧 **Email**: info@situneo.my.id
- 📱 **Phone**: +62 831-7386-8915
- 💬 **WhatsApp**: +62 831-7386-8915

### Business Address
```
Jl. Bekasi Timur IX Dalam No. 27
RT 002/RW 003, Kel. Rawa Bunga
Kec. Jatinegara, Jakarta Timur 13450
DKI Jakarta, Indonesia
```

---

## 🌐 Links

- 🌍 [Website](https://situneo.my.id)
- 📘 [Documentation](docs/)
- 🐛 [Issue Tracker](https://github.com/yourusername/situneo-digital/issues)
- 💡 [Feature Requests](https://github.com/yourusername/situneo-digital/issues)

---

## ⭐ Star History

[![Star History Chart](https://api.star-history.com/svg?repos=yourusername/situneo-digital&type=Date)](https://star-history.com/#yourusername/situneo-digital&Date)

---

## 📊 Stats

![GitHub stars](https://img.shields.io/github/stars/yourusername/situneo-digital?style=social)
![GitHub forks](https://img.shields.io/github/forks/yourusername/situneo-digital?style=social)
![GitHub issues](https://img.shields.io/github/issues/yourusername/situneo-digital)
![GitHub pull requests](https://img.shields.io/github/issues-pr/yourusername/situneo-digital)
![GitHub contributors](https://img.shields.io/github/contributors/yourusername/situneo-digital)

---

<p align="center">
  <strong>Made with ❤️ by SITUNEO DIGITAL</strong>
</p>

<p align="center">
  <strong>Digital Harmony for a Modern World</strong>
</p>

<p align="center">
  <sub>If you find this project useful, please consider giving it a ⭐</sub>
</p>
