<?php
// Database
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'situneo_digital');

// Application
define('APP_NAME', 'SITUNEO DIGITAL');
define('APP_URL', 'https://situneo.my.id');
define('APP_ENV', 'production');

// Email
define('FROM_EMAIL', 'noreply@situneo.my.id');
define('FROM_NAME', 'SITUNEO DIGITAL');

// Security
define('SESSION_LIFETIME', 3600);
define('REMEMBER_LIFETIME', 2592000);
define('ROLE_USER', 0);
define('ROLE_ADMIN', 1);

// Database Connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$conn->set_charset("utf8mb4");

require_once __DIR__ . '/../includes/auth_functions.php';
session_start();
?>
