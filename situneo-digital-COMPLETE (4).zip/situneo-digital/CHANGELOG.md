# Changelog

## [1.0.0] - 2025-01-19

### Added
- Complete authentication system (login, register, password reset)
- User dashboard with profile management
- Order management system with status tracking
- Invoice generation and printing
- Admin panel (users, orders, services management)
- 26 pre-configured digital services
- Multi-language support (Indonesian & English)
- Network background animation
- Responsive design with Bootstrap 5.3.3
- Security features (bcrypt, prepared statements, CSRF protection)
- Email notification system
- Activity logging

© 2025 SITUNEO DIGITAL - NIB: 20250-9261-4570-4515-5453
