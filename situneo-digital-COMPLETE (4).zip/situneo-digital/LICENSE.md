# Proprietary License

Copyright © 2025 SITUNEO DIGITAL
NIB: 20250-9261-4570-4515-5453

All rights reserved.

This software is proprietary and confidential.
Unauthorized copying, modification, or distribution is prohibited.

Contact: info@situneo.my.id
Website: https://situneo.my.id
Phone: +62 831-7386-8915
