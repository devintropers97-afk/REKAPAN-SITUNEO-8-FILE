# 💼 BATCH 02: BUSINESS MODEL - 3 ROLE SYSTEM

---

## 🎯 OVERVIEW SISTEM

SITUNEO DIGITAL menggunakan sistem 3 role yang terintegrasi:
1. **ADMIN** (Internal Team) - Mengelola semua operasional
2. **CLIENT** (Customer) - Memesan dan tracking layanan
3. **FREELANCER/MITRA/PARTNER** - Mencari klien dan dapat komisi

---

## 👨‍💼 ROLE 1: ADMIN (INTERNAL TEAM)

### Hak Akses Penuh (Full Control)

#### 📊 Dashboard Analytics
- Total revenue (daily, monthly, yearly)
- Total orders (pending, in progress, completed)
- Website traffic analytics
- Conversion rate tracking
- Real-time statistics

#### 👥 User Management
- **CRUD Operations:** Create, Read, Update, Delete users
- **User Types:** Admin, Client, Partner/Freelancer
- **Bulk Actions:** Mass update, mass delete, mass suspend
- **Suspend/Activate:** Kontrol akses user
- **User Details:** View full profile, activity logs

#### 📦 Order Management
- **View All Orders:** Filter by status, date, client, service
- **Assign to Freelancer:** (Optional, jika diperlukan)
- **Update Status:** 
  - Pending → In Development
  - In Development → Testing
  - Testing → Completed
  - Cancelled
- **Upload Deliverables:** Upload file hasil kerja (ZIP, PDF, etc)
- **Order Timeline:** Track progress history
- **Notes & Comments:** Internal notes untuk tim

#### 💳 Payment Verification
- **View Payment Proofs:** Bukti transfer dari client
- **Approve/Reject:** Manual verification
- **Payment History:** Semua transaksi
- **Invoice Generation:** Auto-generate PDF invoice
- **Payment Reminders:** Send reminder otomatis

#### 🛠️ Service & Package Management
- **Manage Services:** CRUD 232+ layanan
- **Pricing Control:** Update harga, diskon
- **Feature Management:** Update fitur per service
- **Visibility Control:** Show/hide service
- **Category Management:** 10 divisi layanan

#### 🎨 Portfolio Management
- **50 Demo Websites:** CRUD demo portfolio
- **Categories:** Filter by industry, type
- **Tags:** SEO tags untuk demo
- **Featured Portfolio:** Highlight best works
- **Before/After:** Showcase transformations

#### ⭐ Review Moderation
- **Approve/Reject Reviews:** Moderasi review client
- **Reply to Reviews:** Balasan resmi dari Situneo
- **Hide Inappropriate:** Sembunyikan review tidak pantas
- **Rating Analytics:** Average rating, trends

#### 💰 Withdrawal Management (Partner)
- **View Requests:** Semua request withdrawal
- **Approve/Reject:** Manual approval
- **Minimum:** Rp 50,000
- **Transfer Process:** Proses transfer ke bank partner
- **History:** Track all withdrawals

#### 🎯 Demo Request Management
- **26 Fields Form Data:** Lihat semua data request demo
- **"Copy for AI" Feature:** Copy formatted text untuk AI
- **Assign to Team:** Assign ke designer/developer
- **Status Tracking:** Pending, In Progress, Completed
- **Client Communication:** Reply via email/WA

#### ⚙️ Settings & Configuration
- **Company Info:** Update profil perusahaan
- **SMTP Settings:** Email configuration
- **SEO Settings:** Meta tags, sitemap
- **Backup System:** Auto backup database
- **API Keys:** Payment gateway, OAuth, etc
- **Email Templates:** Customize notification emails

#### 📈 Reports & Analytics
- **Revenue Reports:** Daily, weekly, monthly, yearly
- **Popular Services:** Best-selling services
- **Conversion Tracking:** From visit to order
- **Partner Performance:** Top performers
- **Client Retention:** Repeat customers
- **Export Data:** CSV, Excel, PDF

#### 📝 Activity Logs
- User login/logout
- Order creation/updates
- Payment transactions
- System changes
- Security events

---

## 👤 ROLE 2: CLIENT (CUSTOMER)

### Akses Terbatas (Limited Access)

#### 📊 Dashboard Overview
- **My Orders:** Quick view semua order
- **Recent Invoices:** 5 invoice terakhir
- **Payment Status:** Pending, Paid, Overdue
- **Order Progress:** Visual progress bar
- **Notifications:** Unread notifications count

#### 🎨 Request Demo Gratis
- **26 Fields Form:**
  1. Nama Lengkap
  2. Email
  3. No. WhatsApp
  4. Nama Usaha/Organisasi
  5. Jenis Usaha
  6. Tujuan Website
  7. Target Audience
  8. Warna Favorit
  9. Gaya Desain (Modern, Klasik, Minimalis, dll)
  10. Contoh Website yang Disukai (URL)
  11. Halaman yang Diinginkan
  12. Fitur yang Diperlukan
  13. Logo (Upload/URL)
  14. Foto Produk/Kegiatan (Upload/URL)
  15. Deskripsi Usaha
  16. Alamat Lengkap
  17. Google Maps Link
  18. Social Media Links
  19. Konten Teks (Jika ada)
  20. Bahasa (Indonesia/English/Bilingual)
  21. Domain yang Diinginkan
  22. Budget Range
  23. Timeline Target
  24. Competitor Websites
  25. SEO Keywords (Opsional)
  26. Catatan Tambahan

- **Auto Save Draft:** Save progress otomatis
- **Preview Before Submit:** Review sebelum kirim

#### 🛒 Order Layanan
- **Browse Services:** Catalog 232+ layanan
- **Multi-Service Cart:** Pesan banyak sekaligus
- **Package Selection:** Pilih bundling package
- **Customize Package:** Modify features
- **Price Calculator:** Real-time price calculation
- **Checkout Process:** 
  1. Review cart
  2. Fill detail order
  3. Choose payment method
  4. Submit order

#### 💳 Upload Payment Proof
- **Support Formats:** JPG, PNG, PDF
- **Max Size:** 5 MB
- **Payment Methods:**
  - Bank Transfer (BCA)
  - QRIS (All Banks)
  - Midtrans/Xendit (jika aktif)
- **Auto Notification:** Admin notified instantly
- **Status Tracking:** Pending verification

#### 📍 Track Order Progress
- **Status Timeline:**
  1. **Pending:** Menunggu pembayaran
  2. **Payment Verified:** Pembayaran dikonfirmasi
  3. **In Development:** Sedang dikerjakan
  4. **Testing:** Quality assurance
  5. **Completed:** Selesai & delivered
  
- **Estimated Completion:** Target date
- **Progress Percentage:** Visual indicator
- **Real-time Updates:** Notifikasi setiap perubahan

#### 📥 View & Download Hasil Project
- **Download Links:** ZIP, PDF, atau link hosting
- **Preview:** Preview hasil sebelum download
- **Multiple Downloads:** Download ulang kapan saja
- **Revisi History:** Akses semua versi

#### 📄 Invoices
- **View Invoices:** Semua invoice dalam 1 page
- **Download PDF:** Generate invoice PDF
- **Auto Invoice Number:** Format: INV-YYYYMMDD-XXXX
- **Payment Status:** Lunas, Pending, Overdue
- **Invoice Details:**
  - Nomor invoice
  - Tanggal
  - Due date
  - Items (services)
  - Subtotal
  - Discount (if any)
  - Tax (if applicable)
  - Total

#### 💰 Payment History
- **All Transactions:** Complete payment history
- **Filter:** By date, status, amount
- **Export:** Download as CSV/PDF
- **Receipt:** Download receipt per transaction

#### 👤 Profile Management
- **Edit Profile:**
  - Nama lengkap
  - Email
  - Phone/WhatsApp
  - Alamat
  - Photo profile
  - Company info (opsional)
  
- **Change Password:** Update password
- **Notification Settings:** Email, push, SMS
- **Privacy Settings:** Data sharing preferences

#### 🔔 Notifications
- **Order Updates:** Status changes
- **Payment Status:** Verifikasi pembayaran
- **Delivery:** Hasil sudah siap
- **Promo:** Special offers
- **Support:** Replies to tickets
- **System:** Maintenance, updates

#### 🎧 Support Tickets
- **Create Ticket:**
  - Subject
  - Category (Technical, Billing, General)
  - Priority (Low, Medium, High)
  - Description
  - Attachments
  
- **Chat Interface:** Real-time chat dengan admin
- **Ticket Status:** Open, In Progress, Resolved, Closed
- **Rating:** Rate support quality after resolution

#### ⭐ Review & Rating
- **After Order Completed:**
  - Rating (1-5 stars)
  - Written review
  - Upload photos (opsional)
  
- **Public/Private:** Choose visibility
- **Edit Review:** Update dalam 30 hari
- **Response:** Baca balasan dari Situneo

---

## 🤝 ROLE 3: FREELANCER/MITRA/PARTNER

### Akses Khusus Mitra

#### 📊 Dashboard Earnings
- **Total Komisi Earned:** Lifetime earnings
- **Pending Balance:** Belum bisa di-withdraw
- **Available Balance:** Siap withdraw (min 50K)
- **This Month:** Earnings bulan ini
- **Tier Badge:** Current tier dengan badge visual
- **Progress to Next Tier:** Chart progress

#### 🎯 Jual Produk SITUNEO
- **Referral Link Unik:** `https://situneo.my.id?ref=KODE_UNIK`
- **QR Code Generator:** QR untuk offline promotion
- **Link Statistics:**
  - Total clicks
  - Unique visitors
  - Conversion rate
  - Orders generated

#### 💰 Commission Tracking (15-50%)
- **Commission Rate:** Sesuai tier saat ini
- **Per Order Details:**
  - Order ID
  - Client name
  - Service/Package
  - Order value
  - Commission percentage
  - Commission amount
  - Status (Pending/Paid)
  
- **Total Commission:**
  - This month
  - Last month
  - Last 3 months
  - All time

#### 🏦 Withdrawal Request
- **Minimum:** Rp 50,000
- **Request Form:**
  - Amount to withdraw
  - Bank name
  - Account number
  - Account holder name
  
- **Processing Time:** 1x24 jam setelah approved
- **Status Tracking:** Requested, Approved, Processed, Completed
- **Withdrawal History:** Complete logs

#### 🔗 Referral Link Generator
- **Auto Generate:** Unique code per partner
- **Custom Link:** Branded link opsional
- **Short URL:** Friendly URL
- **Copy to Clipboard:** 1-click copy
- **Social Share:** Direct share ke WA, IG, FB

#### 👥 Client List (dari Referral)
- **All Clients:** Yang order via link kamu
- **Client Details:**
  - Name
  - Email
  - Phone
  - Order history
  - Total spent
  - Commission generated
  
- **Filter & Search:** Easy navigation
- **Export:** Download as CSV

#### 📜 Transaction History
- **Detail Komisi Per Order:**
  - Date
  - Client name
  - Service
  - Order value
  - Commission %
  - Commission amount
  - Payment status
  
- **Filter:** By date, status, amount
- **Export:** CSV, PDF

#### 👤 Profile Setup
- **Personal Info:**
  - Full name
  - Email
  - Phone/WhatsApp
  - Address
  - ID Card (KTP) - Upload
  
- **Bank Account:**
  - Bank name
  - Account number
  - Account holder name
  - Verification status
  
- **Social Media:**
  - Instagram
  - Facebook
  - LinkedIn
  - TikTok
  
- **Tax Info:** NPWP (opsional, untuk tax report)

#### 📈 Performance Statistics
- **Total Sales:** Rupiah amount
- **Total Orders:** Number of orders
- **Conversion Rate:** Click to order %
- **Average Order Value:** AOV
- **Best Month:** Highest earning month
- **Growth:** Month-over-month %
- **Tier History:** Tier progression chart

#### 🎨 Marketing Materials
- **Download Templates:**
  - Instagram Story templates
  - Instagram Post templates
  - Facebook banners
  - WhatsApp status templates
  - Flyer digital (PDF)
  
- **Brand Assets:**
  - Situneo Logo (PNG, SVG)
  - Brand guidelines (PDF)
  - Color palette
  - Typography
  
- **Copywriting Templates:**
  - Sales pitch
  - WhatsApp message templates
  - Email templates
  - Social media captions

#### 🔔 Notifications
- **New Order:** Dapat order baru via link
- **Commission Earned:** Komisi masuk balance
- **Withdrawal Update:** Status withdrawal
- **Tier Change:** Upgrade/downgrade tier
- **Promo Materials:** New templates/materials
- **Performance Report:** Monthly summary

---

## 🔐 PERBEDAAN HAK AKSES

| Fitur | Admin | Client | Partner |
|-------|-------|--------|---------|
| Dashboard Analytics | ✅ Full | ❌ | ❌ |
| Manage Users | ✅ | ❌ | ❌ |
| Manage Services | ✅ | ❌ | ❌ |
| Order Layanan | ✅ | ✅ | ❌ |
| Track Orders | ✅ | ✅ Own | ❌ |
| Payment Verification | ✅ | ❌ | ❌ |
| Referral Link | ❌ | ❌ | ✅ |
| Commission Tracking | ✅ View All | ❌ | ✅ Own |
| Withdraw Request | ❌ | ❌ | ✅ |
| View All Clients | ✅ | ❌ | ✅ Own Referrals |
| Manage Portfolio | ✅ | ❌ | ❌ |
| System Settings | ✅ | ❌ | ❌ |
| Reports | ✅ All | ❌ | ✅ Own |

---

## 💡 WORKFLOW CONTOH

### Scenario 1: Client Order Langsung
```
1. Client browse services → pilih paket → checkout
2. Client upload payment proof
3. Admin verify payment → approve
4. Admin assign order → start development
5. Admin update status → testing → completed
6. Client download hasil
7. Client beri review
```

### Scenario 2: Partner Referral Order
```
1. Partner share link: situneo.my.id?ref=PARTNER123
2. Calon client klik link → browse → order
3. Client upload payment → admin verify
4. System auto hitung komisi untuk Partner (sesuai tier)
5. Komisi masuk "Pending Balance" Partner
6. Order selesai → komisi pindah ke "Available Balance"
7. Partner request withdrawal (min 50K)
8. Admin approve → transfer 1x24 jam
```

---

## 🎯 KEY BENEFITS PER ROLE

### Untuk ADMIN
✅ Central control semua operasi  
✅ Real-time monitoring  
✅ Automated reporting  
✅ Easy team management  

### Untuk CLIENT
✅ Self-service order  
✅ Transparent pricing  
✅ Real-time tracking  
✅ Easy communication  

### Untuk PARTNER
✅ Passive income opportunity  
✅ Flexible working  
✅ Transparent commission  
✅ Marketing support  

---

**© 2020-2025 SITUNEO DIGITAL. All Rights Reserved.**
