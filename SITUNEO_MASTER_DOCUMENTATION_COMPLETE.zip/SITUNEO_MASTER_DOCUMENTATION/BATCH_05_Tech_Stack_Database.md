# 💻 BATCH 05: TECH STACK & DATABASE STRUCTURE

---

## 🛠️ TECHNOLOGY STACK

### Backend
- **PHP:** 8.0+ (ea-php74 di cPanel)
- **Database:** MySQL 8.0+
- **Database Access:** MySQLi & PDO
- **Session Management:** PHP Sessions
- **Email:** PHPMailer

### Frontend
- **Markup:** HTML5 + CSS3
- **Framework:** Bootstrap 5.3.3
- **JavaScript:** ES6+
- **Animations:** GSAP, AOS (Animate On Scroll)
- **Charts:** Chart.js
- **Graphics:** Canvas API (network animation)

### Libraries & Tools
- **Icons:** Bootstrap Icons 1.11.3, Font Awesome (optional)
- **jQuery:** Optional
- **Google Maps API:** Maps integration
- **reCAPTCHA v3:** Spam protection
- **Payment Gateway:** Midtrans/Xendit (optional, setup saat go-live)

### Hosting Environment
- **Control Panel:** cPanel (shared hosting)
- **PHP Version:** 7.4+ (ea-php74)
- **Database:** MySQL 8.0+
- **URL:** https://situneo.my.id (production)
- **SSL:** Active & Auto-renew

---

## 🗄️ DATABASE STRUCTURE (17+ TABLES)

### Database Credentials
```
DB_HOST: localhost
DB_USER: nrrskfvk_user_situneo_digital
DB_PASS: Devin1922$
DB_NAME: nrrskfvk_situneo_digital
Status: ✅ CONNECTED
```

---

### TABLE 1: users
**Purpose:** Store all users (Admin, Client, Partner)

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
role ENUM('admin', 'client', 'partner')
name VARCHAR(100)
email VARCHAR(100) UNIQUE
password VARCHAR(255) -- bcrypt hashed
phone VARCHAR(20)
referral_code VARCHAR(20) UNIQUE -- for partners
referred_by VARCHAR(20) -- referral code used
status ENUM('active', 'suspended', 'pending')
email_verified BOOLEAN DEFAULT FALSE
created_at TIMESTAMP
updated_at TIMESTAMP
```

**Indexes:**
- PRIMARY KEY (id)
- UNIQUE (email)
- UNIQUE (referral_code)
- INDEX (referred_by)

---

### TABLE 2: services
**Purpose:** 232+ layanan catalog

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
division_id INT
name VARCHAR(200)
slug VARCHAR(200) UNIQUE
description TEXT
price_setup DECIMAL(12,2)
price_monthly DECIMAL(12,2)
delivery_days INT
features JSON
target_market TEXT
is_active BOOLEAN DEFAULT TRUE
order_count INT DEFAULT 0
created_at TIMESTAMP
updated_at TIMESTAMP
```

---

### TABLE 3: packages
**Purpose:** 6 bundling packages

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
name VARCHAR(100)
slug VARCHAR(100) UNIQUE
price DECIMAL(12,2)
discount_percentage INT DEFAULT 0
description TEXT
features JSON
services_included JSON
duration_months INT
is_popular BOOLEAN DEFAULT FALSE
is_active BOOLEAN DEFAULT TRUE
created_at TIMESTAMP
updated_at TIMESTAMP
```

---

### TABLE 4: portfolios
**Purpose:** 50 demo website showcase

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
title VARCHAR(200)
category VARCHAR(100)
client_name VARCHAR(100)
url VARCHAR(255)
image_url VARCHAR(255)
description TEXT
technologies JSON
completion_date DATE
is_featured BOOLEAN DEFAULT FALSE
view_count INT DEFAULT 0
created_at TIMESTAMP
```

---

### TABLE 5: orders
**Purpose:** Track semua order dari client

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
order_number VARCHAR(50) UNIQUE
client_id INT (FK to users)
referral_code VARCHAR(20) -- track partner
total_amount DECIMAL(12,2)
discount_amount DECIMAL(12,2) DEFAULT 0
final_amount DECIMAL(12,2)
status ENUM('pending', 'paid', 'processing', 'testing', 'completed', 'cancelled')
payment_method VARCHAR(50)
payment_proof VARCHAR(255)
notes TEXT
created_at TIMESTAMP
updated_at TIMESTAMP
```

---

### TABLE 6: order_items
**Purpose:** Detail items dalam order (multi-service per order)

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
order_id INT (FK to orders)
service_id INT (FK to services) NULL
package_id INT (FK to packages) NULL
quantity INT DEFAULT 1
price DECIMAL(12,2)
subtotal DECIMAL(12,2)
created_at TIMESTAMP
```

---

### TABLE 7: invoices
**Purpose:** Auto-generate invoice per order

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
invoice_number VARCHAR(50) UNIQUE -- Format: INV-YYYYMMDD-XXXX
order_id INT (FK to orders)
client_id INT (FK to users)
total_amount DECIMAL(12,2)
due_date DATE
status ENUM('unpaid', 'paid', 'overdue', 'cancelled')
paid_at TIMESTAMP NULL
created_at TIMESTAMP
```

---

### TABLE 8: payments
**Purpose:** Track payment uploads & verification

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
order_id INT (FK to orders)
amount DECIMAL(12,2)
payment_method VARCHAR(50)
proof_image VARCHAR(255)
status ENUM('pending', 'verified', 'rejected')
verified_by INT (FK to users - admin) NULL
verified_at TIMESTAMP NULL
notes TEXT
created_at TIMESTAMP
```

---

### TABLE 9: reviews
**Purpose:** Client reviews & ratings

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
order_id INT (FK to orders)
client_id INT (FK to users)
service_id INT (FK to services) NULL
rating INT CHECK(rating BETWEEN 1 AND 5)
review TEXT
is_approved BOOLEAN DEFAULT FALSE
admin_reply TEXT NULL
created_at TIMESTAMP
updated_at TIMESTAMP
```

---

### TABLE 10: demo_requests
**Purpose:** 26 fields form untuk demo request

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
name VARCHAR(100)
email VARCHAR(100)
phone VARCHAR(20)
business_name VARCHAR(150)
business_type VARCHAR(100)
website_purpose TEXT
target_audience TEXT
favorite_color VARCHAR(50)
design_style VARCHAR(100)
example_website_url VARCHAR(255)
desired_pages TEXT
required_features TEXT
logo_url VARCHAR(255)
product_images JSON
business_description TEXT
address TEXT
google_maps_link VARCHAR(255)
social_media JSON
content_text TEXT
language VARCHAR(50)
desired_domain VARCHAR(100)
budget_range VARCHAR(100)
timeline VARCHAR(100)
competitor_websites TEXT
seo_keywords TEXT
additional_notes TEXT
status ENUM('pending', 'in_progress', 'completed', 'cancelled')
assigned_to INT (FK to users - admin) NULL
created_at TIMESTAMP
updated_at TIMESTAMP
```

---

### TABLE 11: freelancer_referrals
**Purpose:** Track referral link & conversion

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
partner_id INT (FK to users)
client_id INT (FK to users)
order_id INT (FK to orders) NULL
referral_code VARCHAR(20)
clicked_at TIMESTAMP
converted_at TIMESTAMP NULL
created_at TIMESTAMP
```

---

### TABLE 12: freelancer_commissions
**Purpose:** Commission tracking per order

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
partner_id INT (FK to users)
order_id INT (FK to orders)
order_value DECIMAL(12,2)
tier_at_order VARCHAR(20)
commission_percentage INT
commission_amount DECIMAL(12,2)
status ENUM('pending', 'available', 'withdrawn')
created_at TIMESTAMP
updated_at TIMESTAMP
```

---

### TABLE 13: freelancer_withdrawals
**Purpose:** Withdrawal management (min 50K)

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
partner_id INT (FK to users)
amount DECIMAL(12,2)
bank_name VARCHAR(100)
account_number VARCHAR(50)
account_holder VARCHAR(100)
status ENUM('requested', 'approved', 'processed', 'completed', 'rejected')
requested_at TIMESTAMP
approved_at TIMESTAMP NULL
processed_at TIMESTAMP NULL
completed_at TIMESTAMP NULL
admin_notes TEXT NULL
created_at TIMESTAMP
```

---

### TABLE 14: freelancer_tiers
**Purpose:** Tier progression tracking

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
partner_id INT (FK to users)
tier VARCHAR(20) -- bronze, silver, gold, platinum, diamond
commission_rate INT
total_orders INT
month_orders INT
changed_at TIMESTAMP
reason TEXT -- upgrade/downgrade/maintenance
created_at TIMESTAMP
```

---

### TABLE 15: notifications
**Purpose:** Per-role notifications

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
user_id INT (FK to users)
type VARCHAR(50) -- order, payment, tier, withdrawal, etc
title VARCHAR(200)
message TEXT
is_read BOOLEAN DEFAULT FALSE
action_url VARCHAR(255) NULL
created_at TIMESTAMP
```

---

### TABLE 16: support_tickets
**Purpose:** Ticketing system untuk client support

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
ticket_number VARCHAR(50) UNIQUE
client_id INT (FK to users)
subject VARCHAR(200)
category VARCHAR(100)
priority ENUM('low', 'medium', 'high', 'urgent')
status ENUM('open', 'in_progress', 'resolved', 'closed')
message TEXT
admin_reply TEXT NULL
assigned_to INT (FK to users - admin) NULL
created_at TIMESTAMP
updated_at TIMESTAMP
resolved_at TIMESTAMP NULL
```

---

### TABLE 17: password_resets
**Purpose:** Forgot password tokens

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
email VARCHAR(100)
token VARCHAR(255) UNIQUE
expires_at TIMESTAMP
used BOOLEAN DEFAULT FALSE
created_at TIMESTAMP
```

---

### TABLE 18: settings (Optional)
**Purpose:** System settings & company info

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
key VARCHAR(100) UNIQUE
value TEXT
description TEXT
type VARCHAR(50) -- text, number, json, boolean
created_at TIMESTAMP
updated_at TIMESTAMP
```

---

### TABLE 19: activity_logs (Optional)
**Purpose:** User activity tracking

**Columns:**
```sql
id INT PRIMARY KEY AUTO_INCREMENT
user_id INT (FK to users)
action VARCHAR(100)
table_name VARCHAR(100)
record_id INT
old_value JSON NULL
new_value JSON NULL
ip_address VARCHAR(50)
user_agent TEXT
created_at TIMESTAMP
```

---

## 🔗 DATABASE RELATIONSHIPS

### Key Foreign Keys
```
orders.client_id → users.id
orders.referral_code → users.referral_code
order_items.order_id → orders.id
order_items.service_id → services.id
order_items.package_id → packages.id
invoices.order_id → orders.id
payments.order_id → orders.id
freelancer_commissions.partner_id → users.id (where role='partner')
freelancer_commissions.order_id → orders.id
freelancer_withdrawals.partner_id → users.id
```

---

## ⚡ DATABASE INDEXES

**Critical Indexes for Performance:**
```sql
-- Users
INDEX idx_email ON users(email)
INDEX idx_referral_code ON users(referral_code)
INDEX idx_role ON users(role)

-- Orders
INDEX idx_client_id ON orders(client_id)
INDEX idx_referral_code ON orders(referral_code)
INDEX idx_status ON orders(status)
INDEX idx_created_at ON orders(created_at)

-- Freelancer Commissions
INDEX idx_partner_id ON freelancer_commissions(partner_id)
INDEX idx_status ON freelancer_commissions(status)

-- Notifications
INDEX idx_user_read ON notifications(user_id, is_read)
```

---

## 🎨 DESIGN SYSTEM

### Colors
```css
--primary-blue: #1E5C99
--dark-blue: #0F3057
--gold: #FFB400
--bright-gold: #FFD700
--white: #ffffff
--text-light: #e9ecef
--gradient-primary: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%)
--gradient-gold: linear-gradient(135deg, #FFD700 0%, #FFB400 100%)
```

### Typography
```css
Font Primary: 'Inter' (body text)
Font Heading: 'Plus Jakarta Sans'
Sizes: 12px - 48px
Weights: Regular (400), Medium (500), SemiBold (600), Bold (700)
```

### Animations
- Network particle animation (80 particles via Canvas)
- Circuit pattern overlay
- AOS (Animate On Scroll) effects
- GSAP smooth animations
- Smooth transitions (0.3s ease)
- Hover effects with transform

### UI Components
- Network background (Canvas API)
- Circuit pattern grid
- Floating WhatsApp button (kanan bawah)
- Order notification popup (kiri bawah)
- Back to top button
- Loading screen dengan logo animation
- NIB badge dengan pulse animation
- Stats counter animation

---

## 🔐 SECURITY FEATURES

1. **Password Hashing:** bcrypt algorithm
2. **CSRF Protection:** Token-based
3. **SQL Injection Prevention:** Prepared statements (PDO/MySQLi)
4. **XSS Protection:** htmlspecialchars() + Content Security Policy
5. **Session Security:** Secure, HttpOnly cookies
6. **File Upload Validation:** Type, size, extension checks
7. **Rate Limiting:** Login attempts (max 5x/15 min)
8. **reCAPTCHA v3:** Forms protection
9. **SSL Certificate:** HTTPS enforcement
10. **.htaccess Security Rules:** Directory browsing disabled
11. **Input Validation:** Server-side validation
12. **Role-based Access Control (RBAC):** Per-role permissions
13. **Activity Logging:** Audit trail

---

## 📱 RESPONSIVE DESIGN

- **Mobile-first approach** - Design dimulai dari mobile
- **Breakpoints:** 
  - Mobile: 320px - 767px
  - Tablet: 768px - 1023px
  - Desktop: 1024px - 1919px
  - Large Desktop: 1920px+
- **Touch-friendly buttons** - Minimum 44px tap target
- **Optimized images** - Lazy loading + WebP format
- **Fast page load** - <3 seconds target

---

**© 2020-2025 SITUNEO DIGITAL. All Rights Reserved.**
