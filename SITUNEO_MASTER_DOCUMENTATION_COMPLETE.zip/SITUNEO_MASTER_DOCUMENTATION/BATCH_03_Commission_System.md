# 💰 BATCH 03: COMMISSION SYSTEM - 5 TIER PROGRESSION

---

## 🎯 OVERVIEW SISTEM KOMISI

SITUNEO menggunakan sistem komisi bertingkat (5 TIER) untuk partner/mitra/freelancer:
- **Komisi:** 15% - 50% dari nilai jasa
- **Progression:** Bronze → Silver → Gold → Platinum → Diamond
- **Maintenance:** Wajib maintain minimum orders per bulan
- **Withdrawal:** Minimum Rp 50,000

---

## 🏆 5 TIER LEVELS

### 🥉 TIER 1: BRONZE (15% Komisi)

#### Syarat & Kondisi
- **Starting Tier:** Semua partner baru mulai di sini
- **Komisi Rate:** 15% dari nilai jasa
- **Maintenance:** Tidak ada minimum orders
- **Upgrade Ke Silver:** Capai 6 orders total

#### Benefit Bronze
- ✅ Referral link unik
- ✅ Basic marketing materials
- ✅ Standard support (response < 24 jam)
- ✅ Monthly performance email

#### Contoh Perhitungan
```
Order Value: Rp 2.000.000
Komisi Bronze (15%): Rp 300.000
```

---

### 🥈 TIER 2: SILVER (25% Komisi)

#### Syarat Naik dari Bronze
- **Total Orders Required:** 6 orders (cumulative dari awal)
- **Komisi Rate:** 25% dari nilai jasa
- **Maintenance:** Minimum 3 orders per bulan
- **Gagal Maintenance:** Turun ke Bronze bulan berikutnya

#### Syarat Re-Upgrade (jika turun)
- Harus capai **6 orders total lagi** untuk naik kembali
- Orders dari masa Bronze tidak terhitung

#### Benefit Silver
- ✅ Semua benefit Bronze
- ✅ Advanced marketing kit (more templates)
- ✅ Priority support (response < 12 jam)
- ✅ Monthly performance report (detailed)
- ✅ Akses webinar training bulanan

#### Contoh Perhitungan
```
Order Value: Rp 2.000.000
Komisi Silver (25%): Rp 500.000
```

---

### 🥇 TIER 3: GOLD (35% Komisi)

#### Syarat Naik dari Silver
- **Total Orders Required:** 16 orders (cumulative dari Bronze + Silver)
- **Komisi Rate:** 35% dari nilai jasa
- **Maintenance:** Minimum 8 orders per bulan
- **Gagal Maintenance:** Turun ke Silver bulan berikutnya

#### Syarat Re-Upgrade (jika turun)
- Harus capai **16 orders total lagi** untuk naik kembali
- Orders sebelumnya tidak terhitung

#### Benefit Gold
- ✅ Semua benefit Silver
- ✅ Custom marketing materials (request design)
- ✅ Dedicated account manager
- ✅ Quarterly business review (1-on-1 meeting)
- ✅ Early access to new services
- ✅ Co-branding opportunity (limited)

#### Contoh Perhitungan
```
Order Value: Rp 2.000.000
Komisi Gold (35%): Rp 700.000
```

---

### 💎 TIER 4: PLATINUM (45% Komisi)

#### Syarat Naik dari Gold
- **Total Orders Required:** 31 orders (cumulative dari Bronze + Silver + Gold)
- **Komisi Rate:** 45% dari nilai jasa
- **Maintenance:** Minimum 15 orders per bulan
- **Gagal Maintenance:** Turun ke Gold bulan berikutnya

#### Syarat Re-Upgrade (jika turun)
- Harus capai **31 orders total lagi** untuk naik kembali
- Orders sebelumnya tidak terhitung

#### Benefit Platinum
- ✅ Semua benefit Gold
- ✅ Co-branding opportunities (unlimited)
- ✅ Joint marketing campaigns dengan Situneo
- ✅ Premium support 24/7
- ✅ Annual partnership retreat (gathering tahunan)
- ✅ Revenue sharing opportunities (special projects)
- ✅ White label option (selected partners)

#### Contoh Perhitungan
```
Order Value: Rp 2.000.000
Komisi Platinum (45%): Rp 900.000
```

---

### 👑 TIER 5: DIAMOND (50% Komisi - MAX!)

#### Syarat Naik dari Platinum
- **Total Orders Required:** 51 orders (cumulative dari semua tier)
- **Komisi Rate:** 50% dari nilai jasa (TERTINGGI!)
- **Maintenance:** Minimum 25 orders per bulan
- **Gagal Maintenance:** Turun ke Platinum bulan berikutnya

#### Syarat Re-Upgrade (jika turun)
- Harus capai **51 orders total lagi** untuk naik kembali
- Orders sebelumnya tidak terhitung

#### Benefit Diamond (VIP!)
- ✅ Semua benefit Platinum
- ✅ Exclusive partnership benefits
- ✅ Revenue sharing opportunities (all projects)
- ✅ Strategic business planning session (quarterly)
- ✅ VIP treatment di semua event
- ✅ Partnership awards & recognition (public)
- ✅ Priority feature request
- ✅ Lifetime achievement awards

#### Contoh Perhitungan
```
Order Value: Rp 2.000.000
Komisi Diamond (50%): Rp 1.000.000
```

---

## 📊 TIER PROGRESSION CHART

```
TIER        ORDERS NEEDED    MAINTENANCE    KOMISI
────────────────────────────────────────────────────
🥉 Bronze       Start             -          15%
🥈 Silver       6 total         3/bulan      25%
🥇 Gold         16 total        8/bulan      35%
💎 Platinum     31 total       15/bulan      45%
👑 Diamond      51 total       25/bulan      50%
```

---

## 📈 CONTOH SIMULASI PERJALANAN MITRA

### Mitra A: Success Story 🚀

**BULAN 1 (Bronze 15%)**
- Orders: 8 orders
- Revenue: Rp 16.000.000
- Komisi: Rp 2.400.000 (15%)
- Status: ✅ NAIK KE SILVER (6 orders reached)

**BULAN 2 (Silver 25%)**
- Orders: 12 orders
- Revenue: Rp 24.000.000
- Komisi: Rp 6.000.000 (25%)
- Total Orders: 20 (8+12)
- Status: ✅ NAIK KE GOLD (16 orders reached)

**BULAN 3 (Gold 35%)**
- Orders: 15 orders
- Revenue: Rp 30.000.000
- Komisi: Rp 10.500.000 (35%)
- Total Orders: 35 (20+15)
- Status: ✅ NAIK KE PLATINUM (31 orders reached)

**BULAN 4 (Platinum 45%)**
- Orders: 25 orders
- Revenue: Rp 50.000.000
- Komisi: Rp 22.500.000 (45%)
- Total Orders: 60 (35+25)
- Status: ✅ NAIK KE DIAMOND (51 orders reached)

**BULAN 5 (Diamond 50%)**
- Orders: 30 orders
- Revenue: Rp 60.000.000
- Komisi: Rp 30.000.000 (50%)
- Total Orders: 90
- Status: ✅ MAINTAIN DIAMOND (maintenance: 25/bulan)

**TOTAL 5 BULAN:**
- Total Orders: 90 orders
- Total Revenue: Rp 180.000.000
- Total Komisi: Rp 71.400.000

---

### Mitra B: Maintenance Failure ⚠️

**BULAN 1 (Bronze 15%)**
- Orders: 8 orders
- Status: ✅ NAIK KE SILVER

**BULAN 2 (Silver 25%)**
- Orders: 12 orders
- Status: ✅ NAIK KE GOLD

**BULAN 3 (Gold 35%)**
- Orders: 5 orders ⚠️
- Maintenance: Minimum 8 orders
- Status: ❌ TURUN KE SILVER (maintenance gagal)

**BULAN 4 (Silver 25%)**
- Orders: 4 orders ✅
- Maintenance: Minimum 3 orders
- Status: ✅ MAINTAIN SILVER

**BULAN 5 (Silver 25%)**
- Want Gold? Need: 16 orders total (mulai dari 0 lagi)
- Orders: 7 orders
- Total dari downgrade: 7 orders
- Status: ⏳ BELUM CUKUP untuk Gold

---

## 💰 JASA YANG DAPAT KOMISI

### ✅ DAPAT KOMISI (100%)

#### Kategori A: Website Development
- Landing Page: Rp 350K - Rp 1M
- Multi-page Website: Rp 750K - Rp 3M
- E-Commerce: Rp 1.5M - Rp 8M
- Custom Web App: Rp 2M - Rp 15M
- School Website: Rp 1.2M - Rp 6M
- Portfolio Website: Rp 700K - Rp 2M
- AI-powered Website: Rp 2.5M - Rp 10M

#### Kategori B: Design & Branding
- Logo Design: Rp 500K - Rp 2M
- Brand Identity: Rp 2M - Rp 5M
- UI/UX Design: Rp 1.5M - Rp 4M
- Banner/Poster: Rp 200K - Rp 800K

#### Kategori C: Mobile App
- Android App: Rp 5M - Rp 20M
- iOS App: Rp 6M - Rp 25M
- Hybrid App: Rp 4M - Rp 15M

#### Kategori D: Digital Marketing
- SEO Services: Rp 600K - Rp 1M/bulan
- Social Media Management: Rp 2M/bulan
- Content Creation: Rp 500K - Rp 2M
- Google Ads Management: Rp 1.5M/bulan

#### Kategori E: Maintenance
- Website Maintenance: Rp 150K - Rp 500K/bulan
- Bug Fixing: Rp 300K - Rp 1M
- Content Update: Rp 200K - Rp 500K
- Security Updates: Rp 400K - Rp 800K

#### Kategori F: Content & Copywriting
- Article Writing: Rp 100K - Rp 500K per artikel
- Social Media Captions: Rp 50K - Rp 200K per post
- Ad Copywriting: Rp 200K - Rp 1M
- SEO Content: Rp 150K - Rp 600K

#### Kategori G: AI & Automation
- AI Chatbot: Rp 200K - Rp 2M setup
- CRM System: Rp 1M - Rp 5M
- Email Automation: Rp 500K - Rp 2M
- WhatsApp API: Rp 300K - Rp 1.5M

#### Kategori H: Data & Analytics
- GA4 Setup: Rp 300K - Rp 1M
- Tracking Dashboard: Rp 500K - Rp 2M
- Business Intelligence: Rp 2M - Rp 10M

---

### ❌ TIDAK DAPAT KOMISI (Third-Party)

#### Produk Third-Party (Markup Kecil Saja)
- Domain (.com, .id, dll): Rp 150K - Rp 500K/tahun
- Hosting Shared: Rp 300K - Rp 1M/tahun
- Hosting VPS: Rp 500K - Rp 3M/bulan
- SSL Certificate: Rp 200K - Rp 1M/tahun
- Email Hosting: Rp 150K - Rp 500K/tahun
- Google Workspace: Rp 100K/user/bulan
- Premium Plugins/Themes: Vary
- Stock Photos: Vary
- Third-party Licenses: Vary

**Catatan:** Markup 5-10% untuk operasional, tapi TIDAK masuk perhitungan komisi mitra!

---

## 📧 EMAIL NOTIFICATIONS

### Email 1: Upgrade Tier
```
Subject: 🎉 Selamat! Tier Anda Naik ke [TIER_NAME]!

Halo [PARTNER_NAME],

Kami dengan senang hati mengumumkan bahwa tier partnership 
Anda telah naik ke [TIER_NAME]! 

Performance bulan lalu:
✅ Total Orders: [XX] orders
✅ Target untuk [TIER_NAME]: [YY] orders
✅ Komisi Rate: [ZZ]%

Mulai bulan ini, semua komisi Anda adalah [ZZ]% dari nilai 
jasa yang dikerjakan Situneo.

Untuk mempertahankan tier [TIER_NAME]:
⚠️ Minimum [MIN] orders per bulan

Terima kasih atas dedikasi dan kerja keras Anda! 🚀

Best regards,
SITUNEO DIGITAL Team
```

### Email 2: Peringatan Maintenance
```
Subject: ⚠️ Peringatan: Tier Anda Akan Turun

Halo [PARTNER_NAME],

Tier Anda saat ini: [CURRENT_TIER] ([RATE]%)
Orders bulan ini: [X] order
Minimum required: [MIN] orders
Sisa waktu: [DAYS] hari

Jika tidak mencapai [MIN] orders sebelum akhir bulan, 
tier Anda akan turun ke [LOWER_TIER] ([LOWER_RATE]%) bulan depan.

Ayo semangat closing! 💪

Tips:
- Share referral link di social media
- Follow up clients yang tertarik
- Gunakan marketing materials kami

Best regards,
SITUNEO DIGITAL Team
```

### Email 3: Downgrade Tier
```
Subject: 📉 Update: Tier Partnership Anda

Halo [PARTNER_NAME],

Performance bulan lalu:
Orders: [X] orders
Minimum required: [MIN] orders

Karena tidak mencapai minimum maintenance, tier Anda 
telah berubah menjadi [NEW_TIER] ([NEW_RATE]%) untuk bulan ini.

Jangan khawatir! Anda bisa naik kembali dengan mencapai:
🎯 [REQUIRED] orders total untuk kembali ke [OLD_TIER]

Semangat! Tim kami siap support Anda. 💪

Best regards,
SITUNEO DIGITAL Team
```

### Email 4: Monthly Performance Report
```
Subject: 📊 Monthly Performance Report - [MONTH YEAR]

Halo [PARTNER_NAME],

Berikut performa Anda bulan ini:

🎯 PERFORMANCE SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━
Current Tier: [TIER] ([RATE]%)
Total Orders: [X] orders
Total Revenue: Rp [Y]
Total Commission: Rp [Z]

📈 GROWTH
━━━━━━━━━━━━━━━━━━━━━━━
vs Last Month: [+/- X]%
Best Product: [PRODUCT_NAME]
Avg Order Value: Rp [AOV]

🎯 NEXT MONTH TARGET
━━━━━━━━━━━━━━━━━━━━━━━
Maintenance: [MIN] orders
To Next Tier: [REQUIRED] orders total

Keep up the great work! 🚀

Best regards,
SITUNEO DIGITAL Team
```

---

## 🔄 COMMISSION FLOW

### Step-by-Step Process

1. **Partner Share Link**
   ```
   https://situneo.my.id?ref=PARTNER_CODE
   ```

2. **Client Klik Link & Order**
   - Link tracking tersimpan di cookie (30 hari)
   - Jika order dalam 30 hari, tetap terhitung

3. **Client Bayar LUNAS**
   - Upload bukti transfer
   - Admin verify pembayaran

4. **Komisi Auto Calculate**
   - System hitung komisi sesuai tier
   - Masuk "Pending Balance"

5. **Order Completed**
   - Status: Completed
   - Komisi pindah ke "Available Balance"

6. **Partner Request Withdrawal**
   - Minimum: Rp 50,000
   - Input bank details
   - Submit request

7. **Admin Approve**
   - Verifikasi request
   - Approve/reject

8. **Transfer dalam 1x24 jam**
   - Transfer ke bank partner
   - Email confirmation sent
   - Update status: Completed

---

## 📊 DASHBOARD PARTNER

### Performance Widget
```
┌────────────────────────────────────────┐
│ TIER SAAT INI: 💎 PLATINUM (45%)      │
│                                        │
│  Performance Bulan Ini:                │
│  ████████████████░░░░ 18/15 orders    │
│                                        │
│  Status: ✅ AMAN (maintenance OK)     │
│  Target Diamond: 33 orders lagi        │
│                                        │
│  💰 Earnings This Month: Rp 18.000.000│
└────────────────────────────────────────┘
```

### Commission Breakdown
```
┌─────────────────────────────────────────┐
│ 💰 COMMISSION OVERVIEW                  │
├─────────────────────────────────────────┤
│ Pending Balance     Rp 2.500.000       │
│ Available Balance   Rp 5.800.000       │
│ Total Withdrawn     Rp 42.300.000      │
├─────────────────────────────────────────┤
│ Lifetime Earnings   Rp 50.600.000      │
└─────────────────────────────────────────┘
```

---

## 🎯 TIPS SUKSES UNTUK PARTNER

### 1. Share Actively
- Post di Instagram/Facebook minimal 3x seminggu
- Share di WhatsApp status daily
- Join grup bisnis online

### 2. Follow Up
- Follow up leads dalam 24 jam
- Reminder untuk yang masih pikir-pikir
- Tawarkan demo gratis

### 3. Build Trust
- Testimonial dari client sebelumnya
- Portfolio showcase
- Transparent pricing

### 4. Use Materials
- Download semua marketing materials
- Customize dengan info kontak kamu
- Professional presentation

### 5. Track Performance
- Cek dashboard daily
- Monitor link clicks
- Analyze conversion rate

---

**© 2020-2025 SITUNEO DIGITAL. All Rights Reserved.**
