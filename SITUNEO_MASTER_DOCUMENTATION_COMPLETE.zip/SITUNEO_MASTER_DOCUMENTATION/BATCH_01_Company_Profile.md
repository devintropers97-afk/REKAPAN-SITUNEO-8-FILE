# 🏢 BATCH 01: COMPANY PROFILE

---

## 📋 IDENTITAS BISNIS

**Nama Perusahaan:** SITUNEO DIGITAL  
**Tagline:** Digital Harmony for a Modern World  
**NIB:** 20250-9261-4570-4515-5453  
**NPWP:** 90.296.264.6-002.000  
**Direktur:** Devin Prasetyo Hermawan  
**Tahun Berdiri:** 2020  
**Website:** https://situneo.my.id

---

## 📞 INFORMASI KONTAK

### Email
- **Email Utama:** vins@situneo.my.id
- **Email Support:** support@situneo.my.id

### Telepon & WhatsApp
- **WhatsApp:** +62 831-7386-8915
- **Telepon Kantor:** 021-8880-7229

### Alamat Lengkap
```
Jl. Bekasi Timur IX Dalam No. 27
RT 002 / RW 003
Kelurahan Rawa Bunga
Kecamatan Jatinegara
Jakarta Timur 13450
DKI Jakarta, Indonesia
```

### Koordinat Google Maps
- **Latitude:** -6.2388
- **Longitude:** 106.8753
- **Link:** [Lihat di Google Maps](https://maps.google.com/?q=-6.2388,106.8753)

---

## 🌐 SOCIAL MEDIA

| Platform | Username | Link |
|----------|----------|------|
| Instagram | @situneodigital | https://instagram.com/situneodigital |
| Facebook | @situneodigital | https://facebook.com/situneodigital |
| LinkedIn | /company/situneodigital | https://linkedin.com/company/situneodigital |
| TikTok | @situneodigital | https://tiktok.com/@situneodigital |

---

## ⏰ JAM OPERASIONAL

| Hari | Jam Kerja |
|------|-----------|
| Senin - Jumat | 09:00 - 18:00 WIB |
| Sabtu | 09:00 - 15:00 WIB |
| Minggu | Tutup |

**Response Time:** < 2 jam (selama jam kerja)

---

## 📊 STATISTIK PERUSAHAAN

### Performa Bisnis
- **Total Klien:** 500+ clients
- **Total Project:** 1,200+ projects completed
- **Tingkat Kepuasan:** 4.9/5.0 (98%)
- **Pengalaman:** 5+ tahun di industri
- **Total Review:** 450+ verified reviews

### Kapasitas Tim
- **Core Team:** 4 orang
- **Freelance Network:** Unlimited partners
- **Active Partners:** Growing monthly

---

## 👥 TIM INTI (4 CORE MEMBERS)

### 1. Devin Prasetyo Hermawan
**Posisi:** CEO & Founder  
**Peran:** Strategic leadership & business development

### 2. Budi Santoso
**Posisi:** Chief Technology Officer (CTO)  
**Peran:** Technical architecture & development

### 3. Sarah Wijaya
**Posisi:** Creative Director & Head of Design  
**Peran:** Brand identity & visual design

### 4. Maya Putri
**Posisi:** Head of Digital Marketing  
**Peran:** Marketing strategy & client acquisition

---

## 💳 INFORMASI BANK

### Rekening Bank
**Bank:** BCA (Bank Central Asia)  
**Nomor Rekening:** 2750424018  
**Atas Nama:** Devin Prasetyo Hermawan

### Metode Pembayaran
- ✅ Transfer Bank (BCA)
- ✅ QRIS (Semua Bank)
- ✅ Midtrans/Xendit (Setup saat go-live)

---

## 🎯 VISI PERUSAHAAN

> Menjadi digital agency terdepan di Indonesia yang memberdayakan UMKM dan brand lokal untuk bersaing secara global melalui solusi digital inovatif dan teknologi terkini.

---

## 🚀 MISI PERUSAHAAN (5 POIN)

1. **Solusi Terjangkau untuk UMKM**  
   Menyediakan solusi digital berkualitas tinggi dengan harga terjangkau untuk UMKM Indonesia

2. **Go Digital Strategy**  
   Membantu bisnis lokal go digital dengan strategi dan teknologi yang tepat

3. **Training & Edukasi**  
   Memberikan training dan edukasi digital untuk meningkatkan kapabilitas tim client

4. **Ekosistem Freelancer**  
   Membangun ekosistem kerja sama dengan freelancer berbakat melalui sistem komisi yang adil

5. **Kepuasan 100%**  
   Menjaga kepuasan client melalui support 24/7 dan garansi kepuasan 100%

---

## ⭐ 6 VALUE PROPOSITIONS

### 1. Harga Transparan & Terjangkau
✅ Semua paket sudah transparan  
✅ Bisa dicicil untuk kemudahan pembayaran

### 2. Free Demo 24 Jam
✅ Lihat hasil sebelum membayar  
✅ Request demo gratis

### 3. Kecepatan Delivery
✅ Website siap 7-14 hari kerja  
✅ Fast turnaround time

### 4. Support Profesional
✅ Tim support 24/7  
✅ Response time < 2 jam

### 5. Garansi 100% Kepuasan
✅ Revisi sampai puas  
✅ Uang kembali jika tidak sesuai

### 6. Teknologi Terkini
✅ Stack modern & up-to-date  
✅ SEO-friendly dari awal  
✅ Scalable architecture

---

## 📜 LEGALITAS

### Nomor Induk Berusaha (NIB)
**NIB:** 20250-9261-4570-4515-5453  
**Status:** ✅ Terdaftar & Aktif

### NPWP
**NPWP:** 90.296.264.6-002.000  
**Status:** ✅ Verified

### Kepemilikan
**Pemilik:** Devin Prasetyo Hermawan  
**Jenis Usaha:** Digital Agency / IT Services  
**Status Usaha:** Active

---

## 🌟 KEUNGGULAN KOMPETITIF

### 1. Harga Bersaing
- Lebih murah 30-50% dari kompetitor
- Paket bundling hemat
- Sistem cicilan tersedia

### 2. Kualitas Premium
- Desain profesional & modern
- Code clean & scalable
- Mobile-first approach

### 3. Support Terbaik
- Response cepat < 2 jam
- Tim support 24/7
- Garansi 100% kepuasan

### 4. Teknologi Terkini
- PHP 8.0+, MySQL 8.0+
- Bootstrap 5.3.3
- Modern JavaScript (ES6+)

### 5. Sistem Komisi Terbaik
- Komisi 15-50% untuk mitra
- 5 tier progression system
- Transparent & fair

---

## 📈 MILESTONES

| Tahun | Achievement |
|-------|-------------|
| 2020 | 🚀 Company founded |
| 2021 | 📈 100+ clients milestone |
| 2022 | 🎯 500+ projects completed |
| 2023 | 💼 Team expansion (4 core members) |
| 2024 | 🌐 Launch partner program |
| 2025 | ⭐ 1,200+ projects, 4.9/5.0 rating |

---

## 🎓 SERTIFIKASI & TRAINING

- Google Analytics Certified
- Google Ads Certified
- Facebook Blueprint Certified
- PHP & MySQL Advanced
- UI/UX Design Professional

---

## 🤝 PARTNERSHIPS

### Technology Partners
- Google (Analytics, Ads)
- Facebook Business Partner
- Hosting Providers (cPanel)
- Domain Registrars

### Payment Partners
- Midtrans
- Xendit
- Bank BCA
- QRIS All Banks

---

## 📧 CONTACT FOR INQUIRIES

### General Inquiry
📧 vins@situneo.my.id

### Technical Support
📧 support@situneo.my.id  
📱 WA: +62 831-7386-8915

### Partnership
📧 vins@situneo.my.id  
📱 WA: +62 831-7386-8915

### Career
📧 career@situneo.my.id (jika tersedia)

---

**© 2020-2025 SITUNEO DIGITAL. All Rights Reserved.**
