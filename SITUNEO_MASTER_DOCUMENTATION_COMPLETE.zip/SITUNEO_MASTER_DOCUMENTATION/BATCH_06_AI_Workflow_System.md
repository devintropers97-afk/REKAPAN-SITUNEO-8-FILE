# 🤖 BATCH 06: SITUNEO AI WORKFLOW SYSTEM

---

## 🎯 TUJUAN SISTEM

Sistem Situneo dibuat agar orang tanpa kemampuan coding bisa bikin website profesional dengan bantuan AI (ChatGPT + Claude AI + Claude Code).

**Cukup:** Isi formulir → AI yang ngerjain sisanya

---

## 🧩 3 KASUS UTAMA

### KASUS 1: Website Sudah Ada Contohnya (File Lama/Acak)
**Masalah:** Sudah punya 50 file HTML/CSS/JS di cPanel, tapi acak dan tidak nyambung  
**Tujuan:** Menyatukan file jadi website utuh, rapi, dan bisa dikembangkan sampai 300 file

**Langkah-langkah:**

1. **Masuk ke File Manager di cPanel**
   - Pilih semua file di public_html
   - Klik kanan → Compress → ZIP Archive → websiteku.zip

2. **Download ZIP ke laptop**
   - Jadi kamu gak perlu download satu-satu file

3. **Upload ke GitHub**
   - Ekstrak ZIP di laptop
   - Upload isi folder ke GitHub (bukan ZIP-nya)
   - Repo: `https://github.com/username/websiteku`

4. **Gunakan Claude Code:**
   ```
   "Baca semua file di repo GitHub ini.
   Rapikan struktur folder, pisahkan CSS/JS, hubungkan antarhalaman."
   ```

5. **Gunakan ChatGPT (Situneo):**
   ```
   "Gabungkan hasil Claude Code jadi website utuh.
   Buat versi ZIP final siap upload ke cPanel."
   ```

6. **Upload ke cPanel → Extract ZIP → Website tampil**

✅ **Hasil:** Website rapi, sinkron, dan siap dikembangkan batch-by-batch

---

### KASUS 2: Website Belum Ada, Mulai dari Nol (Demo Website)
**Masalah:** Belum ada contoh, mau bikin tampilan dulu untuk testing di cPanel  
**Tujuan:** Buat website demo cepat biar bisa tampil langsung online

**Langkah-langkah:**

1. **Tulis ide sederhananya:**
   ```
   Nama: Sekolah Pintar Indonesia
   Halaman: Home, Profil, Guru, Kontak
   Warna: Biru muda dan putih
   Tujuan: Website profil sekolah
   ```

2. **Gunakan ChatGPT (Situneo):**
   ```
   "Buatkan website demo sesuai ide ini.
   Gunakan HTML + CSS + JS dasar, desain modern dan ringan.
   Hasil akhir dalam bentuk ZIP siap upload ke cPanel."
   ```

3. **Upload ke cPanel → Extract ZIP → Website tampil online**

4. **Edit langsung di cPanel (jika mau):**
   - Klik kanan index.html → Edit → ubah teks/warna
   - Klik Save Changes

5. **Setelah tampil cocok, kembangkan:**
   - Upload ke GitHub
   - Gunakan Claude Code untuk tambah fitur baru
   - Gunakan ChatGPT lagi untuk finishing + ZIP final

✅ **Hasil:** Website tampil dari nol tanpa coding, bisa langsung diuji dan dikembangkan

---

### KASUS 3: Formulir Super Lengkap untuk Klien (Versi Situneo)
**Masalah:** Klien sering bingung menjelaskan keinginan website-nya  
**Tujuan:** Buat formulir super gampang yang bisa diisi klien tanpa ngerti istilah teknis

---

## 📋 FORMULIR SITUNEO (26 FIELDS)

### Bagian 1: Tentang Usaha/Kegiatan
1. Nama usaha / sekolah / organisasi
2. Ceritain sedikit tentang usaha / kegiatan kamu
3. Tujuan bikin website ini (profil, promosi, pendaftaran, dsb)

### Bagian 2: Tampilan Website
4. Warna utama yang diinginkan (contoh: biru, merah, hijau)
5. Gaya tampilan website (modern, simpel, elegan, ceria, islami)
6. Ada contoh website yang disukai? (tulis link / nama kalau ada)

### Bagian 3: Halaman Website
7. Halaman yang diinginkan (Home, Tentang Kami, Produk, Galeri, Kontak, dll)
8. Isi tiap halaman (kalau sudah tahu, kalau tidak biar Situneo bantu buatkan)

### Bagian 4: Fitur Website
9. Fitur yang ingin ada di website (WA langsung, form kontak, galeri, login admin, blog, dll)
10. Apakah ingin website bisa dua bahasa? (Ya / Tidak / Serahkan ke Situneo)

### Bagian 5: Gambar & Logo
11. Logo usaha / sekolah (upload / kirim link)
12. Foto produk / kegiatan (upload / kirim link)

### Bagian 6: Isi & Kontak
13. Kalimat pembuka atau deskripsi usaha
14. Informasi kontak (WA, email, alamat, sosial media)
15. Kata kunci (SEO) - isi kalau tahu, kalau tidak biar Situneo atur

### Bagian 7: Catatan Akhir
16. Target waktu website selesai
17. Catatan tambahan

---

## ⚙️ ALUR BESAR SITUNEO

| Tahap | Siapa yang Kerja | Deskripsi | Hasil |
|-------|------------------|-----------|-------|
| 1️⃣ | Klien | Isi formulir Situneo | Data lengkap & jelas |
| 2️⃣ | Kamu | Copy hasil ke ChatGPT (Situneo) | Website demo ZIP |
| 3️⃣ | ChatGPT | Bikin website dasar (demo) | File siap upload |
| 4️⃣ | Kamu | Upload ke cPanel & test | Website tampil |
| 5️⃣ | Claude AI | Kasih saran konten & desain | Ide tambahan & isi teks |
| 6️⃣ | Claude Code | Tambah fitur, gabung banyak file | Website lengkap & stabil |
| 7️⃣ | ChatGPT | Finishing & buat ZIP final | Website siap online |
| 8️⃣ | Kamu | Upload final ke hosting | Website live! 🎉 |

---

## 📦 HASIL AKHIR SISTEM SITUNEO

✅ Website bisa dibuat 100% tanpa coding  
✅ Semua file rapi, bisa dikembangkan jadi ratusan halaman  
✅ Klien mudah paham & tidak bingung  
✅ Kamu tinggal jalankan alur, tanpa mikir prompt panjang

---

## 🧰 FILE PENDUKUNG (Struktur GitHub)

```
/Situneo_System/
 ├─ 1_Case_Study/
 │   ├─ Kasus1_ExistingFiles.txt
 │   ├─ Kasus2_WebsiteDemo.txt
 │   └─ Kasus3_FormulirSituneo.txt
 ├─ 2_Templates/
 │   ├─ Prompt_Template_ChatGPT.txt
 │   ├─ Prompt_Template_ClaudeAI.txt
 │   └─ Prompt_Template_ClaudeCode.txt
 ├─ 3_Examples/
 │   ├─ Website_Demo.zip
 │   ├─ Formulir_Situneo.docx
 │   └─ Panduan_Visual.pdf
 └─ README.md
```

---

## 🤖 PROMPT TEMPLATES

### Template untuk ChatGPT (Situneo)
```
Saya punya data klien yang mau bikin website:

[PASTE ISI FORMULIR]

Tolong buatkan website profesional dengan:
- HTML5 + CSS3 + JavaScript
- Bootstrap 5.3.3
- Desain modern dan responsive
- Warna: [WARNA KLIEN]
- Gaya: [GAYA KLIEN]

Output dalam format ZIP yang bisa langsung upload ke cPanel.
```

### Template untuk Claude AI
```
Baca data website ini dan berikan saran:

[PASTE DATA KLIEN]

1. Saran konten untuk setiap halaman
2. Struktur informasi yang efektif
3. Call-to-action yang menarik
4. SEO keywords yang relevan
```

### Template untuk Claude Code
```
Repository GitHub: [URL]

Tugas:
1. Baca semua file di repository
2. Rapikan struktur folder (CSS, JS, images terpisah)
3. Perbaiki link antar halaman
4. Optimize untuk mobile
5. Add basic SEO meta tags
6. Test responsiveness

Output: Pull request dengan perubahan
```

---

## ✨ CATATAN TAMBAHAN

- Semua langkah ini sinkron dengan Claude AI, Claude Code, dan ChatGPT (Situneo)
- Kamu tinggal isi → copy → kirim → upload → jadi website
- Jika klien gak ngerti bagian tertentu, tulis "Serahkan ke Situneo"

---

## 🎓 KALIMAT TAGLINE SISTEM

> "Situneo – sistem pembuatan website berbasis AI yang dirancang agar orang awam pun bisa punya website profesional tanpa perlu belajar coding."

---

## 📊 DEMO REQUEST MANAGEMENT

### Fitur "Copy for AI"

Setiap demo request memiliki tombol **"Copy for AI"** yang akan otomatis format data menjadi prompt siap pakai:

```
📋 COPY FOR AI OUTPUT:

=== INFORMASI KLIEN ===
Nama: [Nama Client]
Email: [Email]
WhatsApp: [Phone]

=== DETAIL USAHA ===
Nama Usaha: [Business Name]
Jenis: [Business Type]
Deskripsi: [Business Description]

=== SPESIFIKASI WEBSITE ===
Tujuan: [Website Purpose]
Target: [Target Audience]
Warna: [Favorite Color]
Gaya: [Design Style]
Contoh: [Example URL]

=== HALAMAN & FITUR ===
Halaman: [Desired Pages]
Fitur: [Required Features]
Bahasa: [Language]

=== KONTEN ===
Logo: [Logo URL]
Foto: [Product Images]
Konten: [Content Text]
Alamat: [Address]
Maps: [Google Maps Link]
Social Media: [Social Media JSON]

=== SEO & DOMAIN ===
Domain: [Desired Domain]
Keywords: [SEO Keywords]
Kompetitor: [Competitor Websites]

=== PROJECT DETAILS ===
Budget: [Budget Range]
Timeline: [Timeline]
Notes: [Additional Notes]

=== REKOMENDASI AI ===
[Di sini admin bisa tambahkan catatan manual]
```

Setelah di-copy, langsung paste ke ChatGPT (Situneo) atau Claude AI untuk generate website.

---

## 🚀 QUICK START GUIDE

### Untuk Admin/Developer:
1. Terima demo request dari client
2. Klik "Copy for AI" pada detail request
3. Paste ke ChatGPT atau Claude AI
4. Generate website ZIP
5. Upload ke cPanel client atau test server
6. Preview & konfirmasi dengan client
7. Finalisasi & deploy

### Untuk Client:
1. Isi formulir demo request (26 fields)
2. Submit form
3. Tunggu demo dalam 24 jam
4. Review hasil demo
5. Approve atau request revisi
6. Lanjut pembayaran jika cocok

---

**© 2020-2025 SITUNEO DIGITAL. All Rights Reserved.**
