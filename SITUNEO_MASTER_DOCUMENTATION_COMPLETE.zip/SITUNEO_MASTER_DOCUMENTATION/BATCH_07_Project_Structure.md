# 📁 BATCH 07: PROJECT STRUCTURE (280 FILES)

---

## 📊 OVERVIEW

**Total Files:** 280 files  
**System:** Modular & Scalable  
**Approach:** Batch-based development (15 batches × ~18 files)

---

## 🗂️ ROOT DIRECTORY

```
📦 SITUNEO DIGITAL ROOT
├── index.php                    # Homepage
├── .htaccess                    # Security & URL rewrites
├── .env.example                 # Environment template
├── robots.txt                   # SEO crawler rules
├── sitemap.xml                  # XML sitemap
└── README.md                    # Documentation
```

---

## 📁 /config (8 files)

```
📂 config/
├── database.php                 # DB connection class
├── constants.php                # Site constants (URL, paths, etc)
├── settings.php                 # Site settings
└── routes.php                   # URL routing (optional)
```

---

## 📁 /includes (25 files)

```
📂 includes/
├── init.php                     # Main initializer
├── session.php                  # Session management
│
├── 📂 functions/                # Utility functions
│   ├── auth.php                 # Authentication helpers
│   ├── string.php               # String utilities
│   ├── validation.php           # Input validation
│   ├── format.php               # Formatting (Rupiah, Date)
│   ├── security.php             # Security helpers
│   ├── email.php                # Email utilities (PHPMailer)
│   ├── file.php                 # File upload handling
│   ├── image.php                # Image processing
│   ├── notification.php         # Notification system
│   ├── activity-log.php         # Activity logging
│   ├── pagination.php           # Pagination helper
│   └── breadcrumb.php           # Breadcrumb generator
│
└── 📂 services/                 # Business logic
    ├── service-functions.php    # Service CRUD
    ├── pricing-calculator.php   # Price calculation
    ├── commission-calculator.php # Commission logic
    ├── tier-checker.php         # Tier management
    └── order-processor.php      # Order processing
```

---

## 📁 /assets (60+ files)

```
📂 assets/
│
├── 📂 css/ (20 files)
│   ├── variables.css            # Colors, fonts, spacing
│   ├── reset.css                # CSS reset
│   ├── typography.css           # Font styles
│   ├── layout.css               # Grid & flexbox
│   ├── components.css           # Buttons, cards, forms
│   ├── utilities.css            # Helper classes
│   ├── animations.css           # Keyframes & transitions
│   ├── responsive.css           # Media queries
│   │
│   ├── 📂 pages/                # Page-specific styles
│   │   ├── homepage.css
│   │   ├── services.css
│   │   ├── portfolio.css
│   │   └── contact.css
│   │
│   └── 📂 admin/                # Admin panel styles
│       ├── admin-base.css
│       ├── dashboard.css
│       └── tables.css
│
├── 📂 js/ (20 files)
│   ├── main.js                  # Core JavaScript
│   ├── animations.js            # Animation effects
│   ├── form-validation.js       # Form validation
│   ├── ajax-handler.js          # AJAX utilities
│   ├── notifications.js         # Toast notifications
│   ├── modal.js                 # Modal handler
│   ├── tabs.js                  # Tabs component
│   ├── accordion.js             # Accordion component
│   ├── slider.js                # Image slider
│   ├── lazy-load.js             # Lazy loading images
│   ├── smooth-scroll.js         # Smooth scrolling
│   ├── pricing-calculator.js    # Interactive calculator
│   └── service-filter.js        # Service filtering
│
└── 📂 images/
    ├── 📂 logo/
    ├── 📂 icons/
    ├── 📂 portfolio/
    ├── 📂 team/
    └── 📂 placeholders/
```

---

## 📁 /components (30 files)

```
📂 components/
│
├── 📂 layout/
│   ├── head.php                 # HTML head + meta tags
│   ├── header.php               # Site header + navbar
│   ├── footer.php               # Site footer
│   └── scripts.php              # JavaScript includes
│
├── 📂 ui/                       # UI Components
│   ├── button.php
│   ├── card.php
│   ├── modal.php
│   ├── alert.php
│   ├── badge.php
│   ├── loader.php
│   └── pagination.php
│
├── 📂 forms/                    # Form Components
│   ├── input.php
│   ├── select.php
│   ├── textarea.php
│   ├── checkbox.php
│   ├── radio.php
│   └── file-upload.php
│
└── 📂 sections/                 # Page Sections
    ├── 📂 homepage/
    │   ├── hero.php
    │   ├── stats.php
    │   ├── services-preview.php
    │   ├── how-it-works.php
    │   ├── portfolio-showcase.php
    │   ├── testimonials.php
    │   ├── pricing-preview.php
    │   ├── faq.php
    │   ├── partners.php
    │   └── cta-banner.php
    │
    ├── 📂 services/
    │   ├── services-hero.php
    │   ├── services-grid.php
    │   ├── services-filter.php
    │   └── services-cta.php
    │
    ├── 📂 portfolio/
    │   ├── portfolio-hero.php
    │   ├── portfolio-filter.php
    │   └── portfolio-grid.php
    │
    └── 📂 contact/
        ├── contact-hero.php
        ├── contact-form.php
        ├── contact-info.php
        └── contact-map.php
```

---

## 📁 /pages (15 files)

```
📂 pages/
├── about.php                    # About us
├── services.php                 # Services catalog
├── service-detail.php           # Dynamic service detail
├── portfolio.php                # Portfolio showcase
├── pricing.php                  # Pricing page
├── calculator.php               # Price calculator
├── blog.php                     # Blog listing
├── blog-detail.php              # Blog post detail
├── contact.php                  # Contact page
├── faq.php                      # FAQ page
├── testimonials.php             # Testimonials page
├── terms.php                    # Terms of service
├── privacy.php                  # Privacy policy
├── career.php                   # Careers page
└── 404.php                      # Error page
```

---

## 📁 /auth (10 files)

```
📂 auth/
├── login.php                    # Login page
├── register.php                 # Registration
├── register-partner.php         # Partner registration (special)
├── logout.php                   # Logout handler
├── forgot-password.php          # Forgot password
├── reset-password.php           # Reset password form
├── verify-email.php             # Email verification
├── resend-verification.php      # Resend verification
├── change-password.php          # Change password
└── oauth-callback.php           # OAuth callback (optional)
```

---

## 📁 /admin (40+ files)

```
📂 admin/
├── index.php                    # Admin dashboard
│
├── 📂 components/
│   ├── sidebar.php
│   ├── header.php
│   ├── stats-card.php
│   ├── chart-widget.php
│   └── table-widget.php
│
├── 📂 orders/
│   ├── index.php                # Orders list
│   ├── detail.php               # Order detail
│   ├── create.php               # Manual order creation
│   └── update-status.php        # Update order status
│
├── 📂 users/
│   ├── index.php                # Users list
│   ├── detail.php               # User detail
│   ├── create.php               # Create user
│   ├── edit.php                 # Edit user
│   └── delete.php               # Delete user
│
├── 📂 services/
│   ├── index.php                # Services list
│   ├── create.php               # Create service
│   ├── edit.php                 # Edit service
│   └── delete.php               # Delete service
│
├── 📂 packages/
│   ├── index.php                # Packages list
│   ├── create.php
│   ├── edit.php
│   └── delete.php
│
├── 📂 portfolio/
│   ├── index.php                # Portfolio list
│   ├── create.php
│   ├── edit.php
│   └── delete.php
│
├── 📂 payments/
│   ├── index.php                # Payment verifications
│   ├── approve.php              # Approve payment
│   └── reject.php               # Reject payment
│
├── 📂 partners/
│   ├── index.php                # Partners list
│   ├── detail.php               # Partner detail & stats
│   └── tier-history.php         # Tier progression
│
├── 📂 withdrawals/
│   ├── index.php                # Withdrawal requests
│   ├── approve.php
│   └── process.php
│
├── 📂 demo-requests/
│   ├── index.php                # Demo requests list
│   ├── detail.php               # Request detail (26 fields)
│   └── copy-for-ai.php          # Copy formatted for AI
│
├── 📂 reports/
│   ├── revenue.php              # Revenue reports
│   ├── services.php             # Popular services
│   ├── partners.php             # Partner performance
│   └── clients.php              # Client retention
│
└── 📂 settings/
    ├── company.php              # Company info
    ├── smtp.php                 # Email settings
    ├── seo.php                  # SEO settings
    └── backup.php               # Backup & restore
```

---

## 📁 /client (18 files)

```
📂 client/
├── index.php                    # Client dashboard
│
├── 📂 orders/
│   ├── index.php                # My orders
│   ├── create.php               # New order
│   ├── detail.php               # Order detail & tracking
│   └── upload-payment.php       # Upload payment proof
│
├── 📂 demo/
│   └── request.php              # Request demo (26 fields)
│
├── 📂 invoices/
│   ├── index.php                # Invoices list
│   └── download.php             # Download PDF
│
├── 📂 payments/
│   └── history.php              # Payment history
│
├── 📂 support/
│   ├── tickets.php              # Support tickets
│   ├── create-ticket.php
│   └── chat.php                 # Ticket chat
│
├── 📂 reviews/
│   └── submit.php               # Submit review
│
└── 📂 profile/
    ├── edit.php                 # Edit profile
    └── change-password.php
```

---

## 📁 /partner (18 files)

```
📂 partner/
├── index.php                    # Partner dashboard
│
├── 📂 earnings/
│   ├── overview.php             # Earnings overview
│   └── commissions.php          # Commission details
│
├── 📂 referrals/
│   ├── link-generator.php       # Generate referral links
│   ├── qr-code.php              # QR code generator
│   └── clients.php              # Client list from referrals
│
├── 📂 withdrawals/
│   ├── request.php              # Request withdrawal
│   └── history.php              # Withdrawal history
│
├── 📂 performance/
│   ├── stats.php                # Performance statistics
│   └── tier-progress.php       # Tier progression chart
│
├── 📂 marketing/
│   └── materials.php            # Download marketing materials
│
└── 📂 profile/
    ├── edit.php                 # Edit profile
    ├── bank-account.php         # Bank account setup
    └── change-password.php
```

---

## 📁 /api (18 files)

```
📂 api/
├── 📂 v1/
│   ├── auth.php                 # Authentication API
│   ├── orders.php               # Orders API
│   ├── services.php             # Services API
│   ├── payments.php             # Payments API
│   ├── commissions.php          # Commissions API
│   └── webhooks.php             # Payment gateway webhooks
│
└── 📂 email-templates/
    ├── welcome.html             # Welcome email
    ├── order-confirmation.html
    ├── payment-verified.html
    ├── order-completed.html
    ├── tier-upgrade.html
    ├── tier-downgrade.html
    └── withdrawal-approved.html
```

---

## 📁 /docs (Optional)

```
📂 docs/
├── README.md                    # Main documentation
├── INSTALLATION.md              # Installation guide
├── DATABASE.md                  # Database schema
├── API.md                       # API documentation
└── CHANGELOG.md                 # Version history
```

---

## 🔄 15 BATCH SYSTEM

### Batch Development Strategy

| Batch | Files | Focus | Priority |
|-------|-------|-------|----------|
| 1 | Core Config & Functions | Foundation | Critical |
| 2 | Database Structure | Data layer | Critical |
| 3 | CSS Assets | Styling | High |
| 4 | JavaScript Assets | Interactivity | High |
| 5 | Layout Components | Structure | High |
| 6 | UI Components | Reusables | Medium |
| 7 | Homepage Sections | Landing | High |
| 8 | Public Pages | Content | High |
| 9 | Auth System | Security | Critical |
| 10 | Admin Core | Management | Critical |
| 11 | Admin Advanced | Features | High |
| 12 | Client Dashboard | User experience | High |
| 13 | Partner Dashboard | Commission system | High |
| 14 | API & Integrations | External services | Medium |
| 15 | Docs, Tests & Extras | Quality | Medium |

---

## ✅ DEVELOPMENT PRINCIPLES

1. **Modular** - 280 files kecil-kecil, mudah maintain
2. **Testable** - Checklist per batch untuk QA
3. **Revisable** - Easy to fix & replace individual files
4. **Trackable** - Progress visible per batch
5. **Documentable** - Guides per batch available
6. **Communicative** - Clear feedback loop with client
7. **Flexible** - Revisi kapan aja tanpa break system
8. **Professional** - Production-ready quality

---

**© 2020-2025 SITUNEO DIGITAL. All Rights Reserved.**
